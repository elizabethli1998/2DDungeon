
#ifndef CS327_EQUIPMENT_H
#define CS327_EQUIPMENT_H
#include "dungeon.h"

void open_menu();
void open_inventory(dungeon *d);
void inventory_menu(dungeon *d);
void equipment_menu(dungeon *d);
void inspection_menu(dungeon *d);
void destroy_menu();
void equip_menu(dungeon *d);
void unequip_menu(dungeon *d);
void drop_menu(dungeon *d);
void expunge_menu(dungeon *d);
void pc_equipment(dungeon *d);
void pc_carry(dungeon *d);
void pickup(dungeon *d);

#endif
