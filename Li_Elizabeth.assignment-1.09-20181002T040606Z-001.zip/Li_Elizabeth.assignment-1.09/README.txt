

This 1.09 Assignment implements using objects in form of equipment and combat functionality.
There are several changes that are needed for this assignment: our PC has default HP and speed,
we now have new commands for w,i,e,t,d,I that are in equipment.cpp and io.cpp,
we can get a description for our inspection menus through object.cpp, we can update
stats now for the PC in move,cpp, along with picking up items and combat accounting
for HP, which are also features in move.cpp. 
In addition, carrying slots and equipment slots are added and handled with equipment.cpp
and equipment.h. Failure handling, numbers, names of items are also given. NPCS will not
attack other NPCS and combat will work fine, with speed and damage bonuses being
implemented to benefit the PC. All attacks connect in this case and damage is applied
through dice rolls.


To run, just use the command "./rlg327" and to compile, call
"make all". Clean with "make clean"

