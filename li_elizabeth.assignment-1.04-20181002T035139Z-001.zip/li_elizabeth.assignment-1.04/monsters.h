# include "macros.h"
#define INTELLIGENCE 0x00000001
#define TELEPATHY  0x00000002
#define TUNNELER   0x00000003
#define ERRATIC    0x00000004
#ifndef MONSTERS_H
# define MONSTERS_H


typedef struct dungeon dungeon_t;
typedef struct event event_t;
typedef struct monster {
	int speed;
	int characteristics;
	int x_pos;
	int y_pos;
	int priority;
} monster_t;


void firstMove(dungeon_t *d, event_t *p);
void secondMove(dungeon_t *d, event_t *p);
void thirdMove(dungeon_t *d, event_t *p);
void fourthMove(dungeon_t *d, event_t *p);
void fifthMove(dungeon_t *d, event_t *p);
void sixthMove(dungeon_t *d, event_t *p);
void seventhMove(dungeon_t *d, event_t *p);
void eighthMove(dungeon_t *d, event_t *p);
void pcMove(dungeon_t *d, event_t *p);
void monsterPlace(dungeon_t *d);
void runMonsters(dungeon_t *d, int numMonsters);


#endif
