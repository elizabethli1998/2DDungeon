 

This 1.04 Assignment implements monsters of 16 different types and allows them to roam around with the PC. PC is placed at a random room that no monster starts off in, and if the PC is touched by a monster, it's game over. Each monster is given certain attributes as well. To add monsters, simply do ./rlg327 --nummon 6
or whichever number of monsters you wish to add.

Added functions include:
priority_queue()-gives PC the highest priority and monsters right after it
monsterPlace()- places monsters on the dungeon in rooms where the PC is not. It goes through each monsters through iteration and places them accordingly.
runMonsters() - implements the moving monsters on the map, this uses the priority queue and will remove events from it. This uses the pcMove() function if a pc event is available. If the event is a monster, it will go through sixteen different conditional if statements to figure out the monster's behaviors and attributes. This function also checks if the monster char touches the PC. If so, it's game over.
pcMove()- allows pc to move around the map, it first moves up, then right, down, left in that order if possible.
firstMove(), secondMove(), thirdMove(), fourthMove(), fifthMove(), sixthMove(),
seventhMove(), eighthMove() are the different movement behaviors
