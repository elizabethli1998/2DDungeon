#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include "dungeon.h"
#include "path.h"
#include "monsters.h"


static int32_t priority_queue(const void *key, const void *with) 
{if( ((event_t *) key)->nextTurn - ((event_t *) with)->nextTurn == 0)
  {return ((event_t *) key)->priority - ((event_t *) with)->priority;}
  else
  {return ((event_t *) key)->nextTurn - ((event_t *) with)->nextTurn;}
}

void monsterPlace(dungeon_t *d)
{	int x, monsterNumbers, y, width, height,positionX, positionY;
	int D = 1;
	for(monsterNumbers=0; monsterNumbers < d->num_monsters; monsterNumbers++)
	  {
	    width = d->rooms[D].size[0];
		height = d->rooms[D].size[1];
		x = d->rooms[D].position[0];
		y = d->rooms[D].position[1];
	    positionY = rand() % height + y;
        positionX = rand() % width + x;
		d->monsters[monsterNumbers].x_pos = positionX;
		d->monsters[monsterNumbers].y_pos = positionY;
		D++;
		if(D == d->num_rooms){D = 1;}
	  }
}
void runMonsters(dungeon_t *d, int numMonsters)
{
	heap_t monsterHeap;
	heap_init(&monsterHeap, priority_queue, NULL);
	pc_t *pc_p = &d->pc;
	
	d->num_monsters = numMonsters;
	d->events = malloc(sizeof(*d->events) * (numMonsters + 1));
	d->events[0].c_type.p = pc_p;
	d->events[0].event = 'p';
	d->events[0].speed = 10;
	d->events[0].priority = 0;
	d->events[0].nextTurn = 1000 / d->events[0].speed;
	d->events[0].hn = heap_insert(&monsterHeap, &d->events[0]);	
	d->monsters = malloc(sizeof (*d->monsters) * numMonsters);
	
	int i;
	srand(time(NULL));
	for(i=0; i < numMonsters; i++)
	  {
  
        d->monsters[i].speed = rand() % (20-5+1) + 5;
		d->monsters[i].priority = i+1;
		d->monsters[i].characteristics = rand() & 0x0000000f;
		d->events[i+1].c_type.m = &d->monsters[i];
		d->events[i+1].event = 'm';
		d->events[i+1].priority = d->monsters[i].priority;
		d->events[i+1].speed = d->monsters[i].speed;
		d->events[i+1].nextTurn = 1000 / d->events[i+1].speed;
		d->events[i+1].hn = heap_insert(&monsterHeap, &d->events[i+1]);
	}

	monsterPlace(d);
	render_dungeon(d);

	static event_t *p;
	int gameOver;
	while ((p = heap_remove_min(&monsterHeap)) && gameOver)
	  {		
		if(p->event == 'p')
		  {	pcMove(d,p);
			dijkstra(d);
			dijkstra_tunnel(d);
			render_dungeon(d);
			p->nextTurn += (1000 / p->speed);
		   }
		else
		  {
			if((p->c_type.m->characteristics & TELEPATHY) && (p->c_type.m->characteristics & ERRATIC)&&(p->c_type.m->characteristics & TUNNELER) && (p->c_type.m->characteristics & INTELLIGENCE))
			{	      
					 if((rand() % 2 + 1)==1){eighthMove(d,p);}
					 else{secondMove(d,p);}
			}
			else if(((p->c_type.m->characteristics & TELEPATHY)  && p->c_type.m->characteristics & INTELLIGENCE) && (p->c_type.m->characteristics & TUNNELER))
					 { eighthMove(d, p);}
			else if( (p->c_type.m->characteristics & TUNNELER) && (p->c_type.m->characteristics & INTELLIGENCE) && (p->c_type.m->characteristics & ERRATIC))
					 {if((rand() % 2 + 1)==1){sixthMove(d,p);}
					  else{secondMove(d,p);}
			}
			else if(((p->c_type.m->characteristics & TELEPATHY) && p->c_type.m->characteristics & INTELLIGENCE) && (p->c_type.m->characteristics & ERRATIC))
					 { if((rand() % 2 + 1)==1){seventhMove(d,p);}
					   else{firstMove(d,p);}
					 }
			else if(((p->c_type.m->characteristics & TUNNELER) && p->c_type.m->characteristics & TELEPATHY) && (p->c_type.m->characteristics & ERRATIC))
					 {    
						 if((rand() % 2 + 1)==1){fourthMove(d,p);}
						 else{secondMove(d,p);}
			}
			else if((p->c_type.m->characteristics & INTELLIGENCE) &&(p->c_type.m->characteristics & TUNNELER)){sixthMove(d,p);}
			else if((p->c_type.m->characteristics & INTELLIGENCE) &&(p->c_type.m->characteristics & TELEPATHY)){seventhMove(d, p);}
			else if((p->c_type.m->characteristics & INTELLIGENCE) &&(p->c_type.m->characteristics & ERRATIC))
			{    
		                 if((rand() % 2 + 1)==1){fifthMove(d,p);}
						 else{firstMove(d,p);}
			}
		    else if((p->c_type.m->characteristics & ERRATIC) && (p->c_type.m->characteristics & TELEPATHY))
		    {     
						 if((rand() % 2 + 1)==1){thirdMove(d,p);}
						 else{secondMove(d,p);}
			}
			else if( (p->c_type.m->characteristics & TUNNELER) && (p->c_type.m->characteristics & TELEPATHY)){fourthMove(d, p);}
			else if((p->c_type.m->characteristics & ERRATIC) && (p->c_type.m->characteristics & TUNNELER)){secondMove(d,p);}
            else if(p->c_type.m->characteristics & TUNNELER){secondMove(d,p);}
			else if(p->c_type.m->characteristics & TELEPATHY){thirdMove(d,p);}
		    else if(p->c_type.m->characteristics & INTELLIGENCE){fifthMove(d,p);}
			else
			{firstMove(d,p);}
			if(d->pc_distance[p->c_type.m->y_pos][p->c_type.m->x_pos] == 0)
			{
				gameOver=0;
				render_dungeon(d);
				printf("You failed! Try again!\n");
			}
			p->nextTurn += (1000 / p->speed);
		  }
		usleep(10000);
		p->hn = heap_insert(&monsterHeap, p);
	}
}

void pcMove(dungeon_t *d, event_t *p)
{
	if(d->map[d->pc.position[1]+1][d->pc.position[0]] > ter_floor){d->pc.position[1] = d->pc.position[1] + 1;}
	else if(d->map[d->pc.position[1]-1][d->pc.position[0]] > ter_floor){d->pc.position[1] = d->pc.position[1] - 1;}
	else if(d->map[d->pc.position[1]][d->pc.position[0]+1] > ter_floor){d->pc.position[0] = d->pc.position[0] + 1;}
	else if(d->map[d->pc.position[1]][d->pc.position[0]-1] > ter_floor){d->pc.position[0] = d->pc.position[0] - 1;}
}

void firstMove(dungeon_t *d, event_t *p){
	
	if((rand() % 2 + 1)==1)
	{
		if(d->map[p->c_type.m->y_pos+1][p->c_type.m->x_pos] > ter_floor){p->c_type.m->y_pos = p->c_type.m->y_pos + 1;}
		else if(d->map[p->c_type.m->y_pos-1][p->c_type.m->x_pos] > ter_floor){p->c_type.m->y_pos = p->c_type.m->y_pos - 1;}
		else if(d->map[p->c_type.m->y_pos][p->c_type.m->x_pos-1] > ter_floor){p->c_type.m->x_pos = p->c_type.m->x_pos - 1;}
        else if(d->map[p->c_type.m->y_pos][p->c_type.m->x_pos+1] > ter_floor){p->c_type.m->x_pos = p->c_type.m->x_pos + 1;}
	}
	else if(rand() % 2 + 1)
	{
		if(d->map[p->c_type.m->y_pos][p->c_type.m->x_pos-1] > ter_floor){p->c_type.m->x_pos = p->c_type.m->x_pos - 1;}
		else if(d->map[p->c_type.m->y_pos-1][p->c_type.m->x_pos] > ter_floor){p->c_type.m->y_pos = p->c_type.m->y_pos - 1;}
		else if(d->map[p->c_type.m->y_pos+1][p->c_type.m->x_pos] > ter_floor){p->c_type.m->y_pos = p->c_type.m->y_pos + 1;}
		else if(d->map[p->c_type.m->y_pos][p->c_type.m->x_pos+1] > ter_floor){p->c_type.m->x_pos = p->c_type.m->x_pos + 1;}
	}
}

void secondMove(dungeon_t *d, event_t *p)
{
        
	
	if((rand() % 4 + 1) == 1)
	{
	   if(d->map[p->c_type.m->y_pos + 1][p->c_type.m->x_pos] != ter_wall_immutable)
	   {
		   if(d->hardness[p->c_type.m->y_pos + 1][p->c_type.m->x_pos] > 0)
		   {if((85 - d->hardness[p->c_type.m->y_pos+1][p->c_type.m->x_pos]) > 0){d->hardness[p->c_type.m->y_pos+1][p->c_type.m->x_pos] = 0;}
				else{d->hardness[p->c_type.m->y_pos+1][p->c_type.m->x_pos] -= 85;}
				dijkstra_tunnel(d);
		   }
			else
			{
				if(d->map[p->c_type.m->y_pos + 1][p->c_type.m->x_pos] == ter_wall)
				{   d->map[p->c_type.m->y_pos + 1][p->c_type.m->x_pos] = ter_floor_hall;
					dijkstra(d);
					dijkstra_tunnel(d);
				}
				p->c_type.m->y_pos = p->c_type.m->y_pos + 1;
			}
		}
	}
	else if((rand() % 4 + 1) == 2)
	{
		if(d->map[p->c_type.m->y_pos][p->c_type.m->x_pos+1] != ter_wall_immutable){
			if(d->hardness[p->c_type.m->y_pos][p->c_type.m->x_pos+1] > 0){
				if((85 - d->hardness[p->c_type.m->y_pos][p->c_type.m->x_pos+1]) > 0){
					d->hardness[p->c_type.m->y_pos][p->c_type.m->x_pos+1] = 0;
				}else{
					d->hardness[p->c_type.m->y_pos][p->c_type.m->x_pos+1] -= 85;
				}
				dijkstra_tunnel(d);
			}else{
				if(d->map[p->c_type.m->y_pos][p->c_type.m->x_pos+1] == ter_wall){
					d->map[p->c_type.m->y_pos][p->c_type.m->x_pos+1] = ter_floor_hall;
					dijkstra(d);
					dijkstra_tunnel(d);
				}
				p->c_type.m->x_pos = p->c_type.m->x_pos + 1;
			}
		}
	}
	else if((rand() % 4 + 1) == 3)
	{
		if(d->map[p->c_type.m->y_pos - 1][p->c_type.m->x_pos] != ter_wall_immutable)
		{
			if(d->hardness[p->c_type.m->y_pos - 1][p->c_type.m->x_pos] > 0){
				if((85 - d->hardness[p->c_type.m->y_pos-1][p->c_type.m->x_pos]) > 0){d->hardness[p->c_type.m->y_pos-1][p->c_type.m->x_pos] = 0;}
				else{d->hardness[p->c_type.m->y_pos-1][p->c_type.m->x_pos] -= 85;}
				dijkstra_tunnel(d);
			}
			else
			{   d->hardness[p->c_type.m->y_pos - 1][p->c_type.m->x_pos] = 0;
				if(d->map[p->c_type.m->y_pos - 1][p->c_type.m->x_pos] == ter_wall)
				{d->map[p->c_type.m->y_pos - 1][p->c_type.m->x_pos] = ter_floor_hall;
					dijkstra(d);
					dijkstra_tunnel(d);
				}
				p->c_type.m->y_pos = p->c_type.m->y_pos - 1;
			}
		}
	}
	else if((rand() % 4 + 1) == 4)
	{
		if(d->map[p->c_type.m->y_pos][p->c_type.m->x_pos-1] != ter_wall_immutable)
		{
			if(d->hardness[p->c_type.m->y_pos][p->c_type.m->x_pos-1] > 0){
				if((85 - d->hardness[p->c_type.m->y_pos][p->c_type.m->x_pos-1]) > 0){d->hardness[p->c_type.m->y_pos][p->c_type.m->x_pos-1] = 0;}
				else{d->hardness[p->c_type.m->y_pos][p->c_type.m->x_pos-1] -= 85;}
				dijkstra_tunnel(d);
			}
			else if(d->hardness[p->c_type.m->y_pos][p->c_type.m->x_pos-1] == 0)
			{
				if(d->map[p->c_type.m->y_pos][p->c_type.m->x_pos-1] == ter_wall)
				{   d->map[p->c_type.m->y_pos][p->c_type.m->x_pos-1] = ter_floor_hall;
					dijkstra(d);
					dijkstra_tunnel(d);
				}
				p->c_type.m->x_pos = p->c_type.m->x_pos-1;
			}
		}
	}
}

void thirdMove(dungeon_t *d, event_t *p)
{
	int x=0;
	int y=0;
	if((p->c_type.m->y_pos - d->pc.position[1]) < 0){y=1;}
	else if((p->c_type.m->y_pos - d->pc.position[1]) > 0){y=-1;}
	if((p->c_type.m->x_pos - d->pc.position[0]) < 0){x=1;}
	else if((p->c_type.m->x_pos - d->pc.position[0]) > 0){x=-1;}
	if(d->map[p->c_type.m->y_pos+y][p->c_type.m->x_pos+x] > ter_floor)
	{	p->c_type.m->y_pos = p->c_type.m->y_pos + y;
		p->c_type.m->x_pos = p->c_type.m->x_pos + x;
	}	
}

void fourthMove(dungeon_t *d, event_t *p)
{
	int x=0;
	int y=0;
	if((p->c_type.m->y_pos - d->pc.position[1]) < 0){y=1;}
	else if((p->c_type.m->y_pos - d->pc.position[1]) > 0){y=-1;}
	if((p->c_type.m->x_pos - d->pc.position[0]) < 0){x=1;}
	else if((p->c_type.m->x_pos - d->pc.position[0]) > 0){x=-1;}
	if(d->hardness[p->c_type.m->y_pos+y][p->c_type.m->x_pos+x] > 0)
	{if((85 - d->hardness[p->c_type.m->y_pos+y][p->c_type.m->x_pos+x]) > 0){d->hardness[p->c_type.m->y_pos+y][p->c_type.m->x_pos+x] = 0;}
		else{d->hardness[p->c_type.m->y_pos+y][p->c_type.m->x_pos+x] -= 85;}
		dijkstra_tunnel(d);
	}
	else if(d->hardness[p->c_type.m->y_pos+y][p->c_type.m->x_pos+x] == 0)
	{if(d->map[p->c_type.m->y_pos+y][p->c_type.m->x_pos+x] == ter_wall)
		{d->map[p->c_type.m->y_pos+y][p->c_type.m->x_pos+x] = ter_floor_hall;
			dijkstra(d);
			dijkstra_tunnel(d);
		}
		p->c_type.m->y_pos = p->c_type.m->y_pos+y;
		p->c_type.m->x_pos = p->c_type.m->x_pos+x;
	}
}

void fifthMove(dungeon_t *d, event_t *p)
{
	if((p->c_type.m->x_pos - d->pc.position[0]) < 20  &&  (p->c_type.m->y_pos - d->pc.position[1]) > -20){seventhMove(d, p);}
	else{firstMove(d, p);}
}

void sixthMove(dungeon_t *d, event_t *p)
{
	if((p->c_type.m->x_pos - d->pc.position[0]) < 20 && (p->c_type.m->y_pos - d->pc.position[1]) > -20 ){eighthMove(d, p);}
	else{secondMove(d, p);}
}

void seventhMove(dungeon_t *d, event_t *p)
{
	if(d->pc_distance[p->c_type.m->y_pos+1][p->c_type.m->x_pos] < d->pc_distance[p->c_type.m->y_pos][p->c_type.m->x_pos])
	{
		p->c_type.m->y_pos = p->c_type.m->y_pos + 1;
	}
	else if(d->pc_distance[p->c_type.m->y_pos-1][p->c_type.m->x_pos] < d->pc_distance[p->c_type.m->y_pos][p->c_type.m->x_pos])
	{
		p->c_type.m->y_pos = p->c_type.m->y_pos - 1;
	}
	else if(d->pc_distance[p->c_type.m->y_pos][p->c_type.m->x_pos+1] < d->pc_distance[p->c_type.m->y_pos][p->c_type.m->x_pos])
	{
		p->c_type.m->x_pos = p->c_type.m->x_pos + 1;
	}
	
	else if(d->pc_distance[p->c_type.m->y_pos+1][p->c_type.m->x_pos+1] < d->pc_distance[p->c_type.m->y_pos][p->c_type.m->x_pos])
	{
		p->c_type.m->y_pos = p->c_type.m->y_pos + 1;
		p->c_type.m->x_pos = p->c_type.m->x_pos + 1;
	}
	else if(d->pc_distance[p->c_type.m->y_pos][p->c_type.m->x_pos-1] < d->pc_distance[p->c_type.m->y_pos][p->c_type.m->x_pos])
	{
		p->c_type.m->x_pos = p->c_type.m->x_pos - 1;
	}
		else if(d->pc_distance[p->c_type.m->y_pos+1][p->c_type.m->x_pos-1] < d->pc_distance[p->c_type.m->y_pos][p->c_type.m->x_pos])
	{
		p->c_type.m->y_pos = p->c_type.m->y_pos + 1;
		p->c_type.m->x_pos = p->c_type.m->x_pos - 1;
	}
	else if(d->pc_distance[p->c_type.m->y_pos-1][p->c_type.m->x_pos+1] < d->pc_distance[p->c_type.m->y_pos][p->c_type.m->x_pos])
	{
		p->c_type.m->y_pos = p->c_type.m->y_pos - 1;
		p->c_type.m->x_pos = p->c_type.m->x_pos + 1;
	}
	else if(d->pc_distance[p->c_type.m->y_pos-1][p->c_type.m->x_pos-1] < d->pc_distance[p->c_type.m->y_pos][p->c_type.m->x_pos])
	{
		p->c_type.m->y_pos = p->c_type.m->y_pos - 1;
		p->c_type.m->x_pos = p->c_type.m->x_pos - 1;
	}	
}

void eighthMove(dungeon_t *d, event_t *p)
{if(d->pc_tunnel[p->c_type.m->y_pos+1][p->c_type.m->x_pos] < d->pc_tunnel[p->c_type.m->y_pos][p->c_type.m->x_pos])
	{if(d->hardness[p->c_type.m->y_pos+1][p->c_type.m->x_pos] > 0){
			if((85 - d->hardness[p->c_type.m->y_pos+1][p->c_type.m->x_pos]) > 0){d->hardness[p->c_type.m->y_pos+1][p->c_type.m->x_pos] = 0;}
			else{d->hardness[p->c_type.m->y_pos+1][p->c_type.m->x_pos] -= 85;}
			dijkstra_tunnel(d);
		}
		else if(d->hardness[p->c_type.m->y_pos+1][p->c_type.m->x_pos] == 0){
			if(d->map[p->c_type.m->y_pos+1][p->c_type.m->x_pos] == ter_wall){
				d->map[p->c_type.m->y_pos+1][p->c_type.m->x_pos] = ter_floor_hall;
				dijkstra(d);
				dijkstra_tunnel(d);
			}
			p->c_type.m->y_pos = p->c_type.m->y_pos+1;
		}
	}
	else if(d->pc_tunnel[p->c_type.m->y_pos-1][p->c_type.m->x_pos] < d->pc_tunnel[p->c_type.m->y_pos][p->c_type.m->x_pos])
	{
		if(d->hardness[p->c_type.m->y_pos-1][p->c_type.m->x_pos] > 0)
		{
			if((85 - d->hardness[p->c_type.m->y_pos-1][p->c_type.m->x_pos]) > 0){d->hardness[p->c_type.m->y_pos-1][p->c_type.m->x_pos] = 0;}
			else{d->hardness[p->c_type.m->y_pos-1][p->c_type.m->x_pos] -= 85;}
			dijkstra_tunnel(d);
		}
		else if(d->hardness[p->c_type.m->y_pos-1][p->c_type.m->x_pos] == 0)
		{if(d->map[p->c_type.m->y_pos-1][p->c_type.m->x_pos] == ter_wall)
			{ d->map[p->c_type.m->y_pos-1][p->c_type.m->x_pos] = ter_floor_hall;
				dijkstra(d);
				dijkstra_tunnel(d);
			}
			p->c_type.m->y_pos = p->c_type.m->y_pos-1;
		}
	}
	else if(d->pc_tunnel[p->c_type.m->y_pos][p->c_type.m->x_pos+1] < d->pc_tunnel[p->c_type.m->y_pos][p->c_type.m->x_pos])
	{
		if(d->hardness[p->c_type.m->y_pos][p->c_type.m->x_pos+1] > 0)
		{
			if((85 - d->hardness[p->c_type.m->y_pos][p->c_type.m->x_pos+1]) > 0)
			{d->hardness[p->c_type.m->y_pos][p->c_type.m->x_pos+1] = 0;}
			else
			{d->hardness[p->c_type.m->y_pos][p->c_type.m->x_pos+1] -= 85;}
			dijkstra_tunnel(d);
		}
		else if(d->hardness[p->c_type.m->y_pos][p->c_type.m->x_pos+1] == 0)
		{
			if(d->map[p->c_type.m->y_pos][p->c_type.m->x_pos+1] == ter_wall)
			{d->map[p->c_type.m->y_pos][p->c_type.m->x_pos+1] = ter_floor_hall;
				dijkstra(d);
				dijkstra_tunnel(d);
			}
			p->c_type.m->x_pos = p->c_type.m->x_pos+1;
		}
	}
	else if(d->pc_tunnel[p->c_type.m->y_pos][p->c_type.m->x_pos-1] < d->pc_tunnel[p->c_type.m->y_pos][p->c_type.m->x_pos])
	{
		if(d->hardness[p->c_type.m->y_pos][p->c_type.m->x_pos-1] > 0)
		{
			if((85 - d->hardness[p->c_type.m->y_pos][p->c_type.m->x_pos-1]) > 0){d->hardness[p->c_type.m->y_pos][p->c_type.m->x_pos-1] = 0;}
			else
			{d->hardness[p->c_type.m->y_pos][p->c_type.m->x_pos-1] -= 85;}
			dijkstra_tunnel(d);
		}
		else if(d->hardness[p->c_type.m->y_pos][p->c_type.m->x_pos-1] == 0)
		{
			if(d->map[p->c_type.m->y_pos][p->c_type.m->x_pos-1] == ter_wall)
			{	d->map[p->c_type.m->y_pos][p->c_type.m->x_pos-1] = ter_floor_hall;
				dijkstra(d);
				dijkstra_tunnel(d);
			}
			p->c_type.m->x_pos = p->c_type.m->x_pos-1;
		}
	}
	else if(d->pc_tunnel[p->c_type.m->y_pos+1][p->c_type.m->x_pos+1] < d->pc_tunnel[p->c_type.m->y_pos][p->c_type.m->x_pos])
	{
		if(d->hardness[p->c_type.m->y_pos+1][p->c_type.m->x_pos+1] > 0)
		{
			if((85 - d->hardness[p->c_type.m->y_pos+1][p->c_type.m->x_pos+1]) > 0)
			{d->hardness[p->c_type.m->y_pos+1][p->c_type.m->x_pos+1] = 0;}
			else
			{d->hardness[p->c_type.m->y_pos+1][p->c_type.m->x_pos+1] -= 85;}
			dijkstra_tunnel(d);
		}
		else if(d->hardness[p->c_type.m->y_pos+1][p->c_type.m->x_pos+1] == 0)
		{
			if(d->map[p->c_type.m->y_pos+1][p->c_type.m->x_pos+1] == ter_wall){
				d->map[p->c_type.m->y_pos+1][p->c_type.m->x_pos+1] = ter_floor_hall;
				dijkstra(d);
				dijkstra_tunnel(d);
			}
			p->c_type.m->y_pos = p->c_type.m->y_pos+1;
			p->c_type.m->x_pos = p->c_type.m->x_pos+1;
		}
	}
	else if(d->pc_tunnel[p->c_type.m->y_pos-1][p->c_type.m->x_pos+1] < d->pc_tunnel[p->c_type.m->y_pos][p->c_type.m->x_pos])
	{
		if(d->hardness[p->c_type.m->y_pos-1][p->c_type.m->x_pos+1] > 0)
		{
			if((85 - d->hardness[p->c_type.m->y_pos-1][p->c_type.m->x_pos+1]) > 0){d->hardness[p->c_type.m->y_pos-1][p->c_type.m->x_pos+1] = 0;}
			else{d->hardness[p->c_type.m->y_pos-1][p->c_type.m->x_pos+1] -= 85;}
			dijkstra_tunnel(d);
		}
		else if(d->hardness[p->c_type.m->y_pos-1][p->c_type.m->x_pos+1] == 0)
		{
			if(d->map[p->c_type.m->y_pos-1][p->c_type.m->x_pos+1] == ter_wall)
			{d->map[p->c_type.m->y_pos-1][p->c_type.m->x_pos+1] = ter_floor_hall;
				dijkstra(d);
				dijkstra_tunnel(d);
			}
			p->c_type.m->y_pos = p->c_type.m->y_pos-1;
			p->c_type.m->x_pos = p->c_type.m->x_pos+1;
		}
	}
	else if(d->pc_tunnel[p->c_type.m->y_pos+1][p->c_type.m->x_pos-1] < d->pc_tunnel[p->c_type.m->y_pos][p->c_type.m->x_pos])
	{
		if(d->hardness[p->c_type.m->y_pos+1][p->c_type.m->x_pos-1] > 0)
		{
			if((85 - d->hardness[p->c_type.m->y_pos+1][p->c_type.m->x_pos-1]) > 0){d->hardness[p->c_type.m->y_pos+1][p->c_type.m->x_pos-1] = 0;}
			else
			{d->hardness[p->c_type.m->y_pos+1][p->c_type.m->x_pos-1] -= 85;}
			dijkstra_tunnel(d);
		}
		else if(d->hardness[p->c_type.m->y_pos+1][p->c_type.m->x_pos-1] == 0)
		{
			if(d->map[p->c_type.m->y_pos+1][p->c_type.m->x_pos-1] == ter_wall)
			{d->map[p->c_type.m->y_pos+1][p->c_type.m->x_pos-1] = ter_floor_hall;
				dijkstra(d);
				dijkstra_tunnel(d);
			}
			p->c_type.m->y_pos = p->c_type.m->y_pos+1;
			p->c_type.m->x_pos = p->c_type.m->x_pos-1;
		}
	}
	else if(d->pc_tunnel[p->c_type.m->y_pos-1][p->c_type.m->x_pos-1] < d->pc_tunnel[p->c_type.m->y_pos][p->c_type.m->x_pos])
	{
		if(d->hardness[p->c_type.m->y_pos-1][p->c_type.m->x_pos-1] > 0)
		{
			if((85 - d->hardness[p->c_type.m->y_pos-1][p->c_type.m->x_pos-1]) > 0){d->hardness[p->c_type.m->y_pos-1][p->c_type.m->x_pos-1] = 0;}
			else
			{d->hardness[p->c_type.m->y_pos-1][p->c_type.m->x_pos-1] -= 85;}
			dijkstra_tunnel(d);
		}
		else if(d->hardness[p->c_type.m->y_pos-1][p->c_type.m->x_pos-1] == 0)
		{
			if(d->map[p->c_type.m->y_pos-1][p->c_type.m->x_pos-1] == ter_wall)
			{   d->map[p->c_type.m->y_pos-1][p->c_type.m->x_pos-1] = ter_floor_hall;
				dijkstra(d);
				dijkstra_tunnel(d);
			}
			p->c_type.m->y_pos = p->c_type.m->y_pos-1;
			p->c_type.m->x_pos = p->c_type.m->x_pos-1;
		}
	}
}
