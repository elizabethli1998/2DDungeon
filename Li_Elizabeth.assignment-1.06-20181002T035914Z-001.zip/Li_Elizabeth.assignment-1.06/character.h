#ifndef CHARACTER_H
# define CHARACTER_H

# include <stdint.h>

# include "dims.h"

# ifdef __cplusplus
extern "C" {
# endif

typedef struct dungeon dungeon_t;

typedef enum kill_type {
  kill_direct,
  kill_avenged,
  num_kill_types
} kill_type_t;

typedef struct {
} character_t;
uint32_t characterSight(dungeon_t *d, pair_t voyeur, pair_t exhibitionist, int is_pc);
uint32_t characterTurn(const character_t *c);
int32_t characterCompareTurn(const void *character1,
                                        const void *character2);
int8_t *character_get_pos(const character_t *c);
int8_t character_get_y(const character_t *c);
int8_t character_get_x(const character_t *c);
int characterAlive(const character_t *c);
void character_delete(void *c);
void characterY(character_t *c, int8_t y);
void characterX(character_t *c, int8_t x);
void deadCharacter(character_t *c);
void characterNext(character_t *c);
void characterReset(character_t *c);
char characterSymbol(const character_t *c);
# ifdef __cplusplus
}

class character {
 public:
  char symbol;
  pair_t position;
  int32_t speed;
  uint32_t next_turn;
  uint32_t alive;
    /* Characters use to have a next_turn for the move queue.  Now that it is *
   * an event queue, there's no need for that here.  Instead it's in the    *
   * event.  Similarly, sequence_number was introduced in order to ensure   *
   * that the queue remains stable.  Also no longer necessary here, but in  *
   * this case, we'll keep it, because it provides a bit of interesting     *
   * metadata: locally, how old is this character; and globally, how many   *
   * characters have been created by the game.                              */
  uint32_t sequence_number;
  uint32_t kills[num_kill_types];
};

# endif
#endif
