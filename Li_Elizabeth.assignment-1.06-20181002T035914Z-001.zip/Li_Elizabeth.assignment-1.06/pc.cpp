#include <stdlib.h>

#include "string.h"

#include "dungeon.h"
#include "pc.h"
#include "utils.h"
#include "move.h"
#include "path.h"

void delete_pc(character_t *the_pc)
{delete (pc *) the_pc;}
uint32_t pc_is_alive(dungeon_t *d)
{return ((pc *) d->pc)->alive;}
void place_pc(dungeon_t *d)
{
  ((pc *) d->pc)->position[dim_y] = rand_range(d->rooms->position[dim_y],
                                               (d->rooms->position[dim_y] +
                                                d->rooms->size[dim_y] - 1));
  ((pc *) d->pc)->position[dim_x] = rand_range(d->rooms->position[dim_x],
                                               (d->rooms->position[dim_x] +
                                                d->rooms->size[dim_x] - 1));
  firstKnownTerrain(d->pc);
  seenTerrain(d->pc, d);
}
void config_pc(dungeon_t *d)
{
  pc *pc1;
  pc1 = new pc;
  d->pc = (character_t *) pc1;
  pc1->symbol = '@';
  place_pc(d);
  pc1->speed = PC_SPEED;
  pc1->next_turn = 0;
  pc1->alive = 1;
  pc1->sequence_number = 0;
  d->character[pc1->position[dim_y]][pc1->position[dim_x]] = (character_t *) d->pc;
  dijkstra(d);
  dijkstra_tunnel(d);
}
uint32_t pc_next_pos(dungeon_t *d, pair_t dir)
{
  dir[dim_y] = dir[dim_x] = 0;
  if (in_corner(d, d->pc)) 
   {
    dir[dim_y] = (mapxy(((pc *) d->pc)->position[dim_x],
                        ((pc *) d->pc)->position[dim_y] - 1) == ter_wall_immutable) ? 1 : -1;} 
  else {dir_nearest_wall(d, d->pc, dir);}
  return 0;
}
void resetVisibility(character_t *pc1)
{
  uint32_t i, j;
  for (i = 0; i < DUNGEON_Y; i++) {
    for (j = 0; j < DUNGEON_X; j++) { ((pc *) pc1)->visible[i][j] = 0;}
 }
}
int32_t isLit(character_t *the_pc, int8_t y, int8_t x){ return ((pc *) the_pc)->visible[y][x];}
terrain_type_t knowTerrain(character_t *pc1, int8_t y, int8_t x){return ((pc *) pc1)->known_terrain[y][x];}
void pcRemember(character_t *pc1, pair_t pos, terrain_type_t ter)
{((pc *) pc1)->known_terrain[pos[dim_y]][pos[dim_x]] = ter;
  ((pc *) pc1)->visible[pos[dim_y]][pos[dim_x]] = 1;
}
void firstKnownTerrain(character_t *pc1)
{  uint32_t i, j;
  for (i = 0; i < DUNGEON_Y; i++){
    for (j = 0; j < DUNGEON_X; j++){
      ((pc *) pc1)->known_terrain[i][j] = ter_mystery;
      ((pc *) pc1)->visible[i][j] = 0;}}
}
void seenTerrain(character_t *pc1, dungeon_t *d){
  pc *p;
  pair_t at;
  int8_t x1, x2, y1, y2;
  p = (pc *) pc1;
   x1 = p->position[dim_x] - PC_VISUAL_RANGE;
  if (x1 < 0) { x1 = 0; }
  x2 = p->position[dim_x] + PC_VISUAL_RANGE - 2;
  if (x2 > DUNGEON_X - 1) {x2 = DUNGEON_X - 1;}
  y1 = p->position[dim_y] - PC_VISUAL_RANGE;
  if (y1 < 0) {y1 = 0; }
  y2 = p->position[dim_y] + PC_VISUAL_RANGE - 2;
  if (y2 > DUNGEON_Y - 1) {y2 = DUNGEON_Y - 1;}
   for(at[dim_x] = x1 - 1; at[dim_x] <= x2 - 1; at[dim_x]++)
  { at[dim_y] = y1;
   characterSight(d, p->position, at, 1);
    at[dim_y] = y2;
    characterSight(d, p->position, at, 1);
  }  
  for(at[dim_y] = y1; at[dim_y] <= y2; at[dim_y]++)
 {  at[dim_x] = x1;
    characterSight(d, p->position, at, 1);
    at[dim_x] = x2;
    characterSight(d, p->position, at, 1);
  }             
}

