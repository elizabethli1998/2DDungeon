This 1.06 Assignment implements Fog of War and ports from C to C++. The PC is now given a mostly 
unlit dungeon to traverse through, with memory of the terrain that was previously seen. A
limited illuminated portion of the dungeon is provided, depending on the position of the PC,
and the PC's line of sight is also limited, while the NPC has more leeway.
To run, simply enter ./rlg327 after doing make all. make clobber will do the same as make clean.

-character.cpp and character.h now are ported. character.cpp now has new functions that help determine
whether: character is dead, turns, positions,alive, and reset. This helps with npc and pc files
to help with teleporting and fog of war.
-io is adjusted to account for teleportation and fog, with handling input functions and
teleporting and displaying functions also being changed. To turn off fog for a turn, press "f".
Teleporting should be "t" and "r" respectively.
-npc.cpp and npc.h now have functions that help with the line of sight and fog
-pc.cpp and pc.h now have functions for memorizing terrain, resetting, finding sight, illuminating,
resetting, etc.