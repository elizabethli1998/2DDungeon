Our Third assignment involves saving and loading the dungeon. 
load: This function opens up the file, and can be called however many times in order to open different file. The second part of load transverses through the dungeon that is loaded and puts in hardness values for every part of the dungeon, allowing it to render. Finally, we go through room array at every room positions and iterate through to mark every room in the dungeon we have loaded. We then render the dungeon,

If the user inputs the the save, aka "--save", the dungeon that is loaded or generated. We then go through the hardness of the dungeons cells, making sure every single one is traversed through. 

Main pulls  the save and load functions. We simply call "--save" and '--load". We can also call the two switches at once and it will load and save at the same time. dungeon.txt is what keeps track and saves the files, with our path /.rlg327/dungeon or dungeon.txt. We can also load files can be done by changing our path to "/.rlg327/(Insert some number that the test file is named).rlg327";
