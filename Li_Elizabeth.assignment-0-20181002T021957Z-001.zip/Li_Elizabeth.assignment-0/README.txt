


This folder contains the relevant file: assignment0.c 
To run the program, simply enter the command "./assignment0". 
The program is designed to solve the N Queens problem with 8 queens. 
In theory, this should be able to solve any other number of queens, 
if there was a prompt with scanf that would allow the user to enter number of queens. 
This program will print all 92 solutions, in alphabetical order and will 
also print the grid visualization with rows a-h and columns 1-8. 
Important functions in this program also include: printSolution(), 
which prints everything for the user to see, safe(), which checks for attackable positions 
on the board for each queen, and markQueen(), a recursive function which places the queens 
on the board after checking to see if it's safe. In this case, our main method will create 
the board, which is a 2D array with [8][8] dimensions and then call the queen function.

