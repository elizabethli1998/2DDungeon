#Changelog

All notable changes to the project will be documented in this file

## 0.01 - 2018-1-11
### Added
- This Changelog file to keep track of all updates and significant changes made to Assignment 0
- Started Assignment 0
- Wrote out basic logic and psuedocode behind Queens problem
- Wrote out the boolean function attacked to check the board's spaces for any attackable spaces

## 0.02 - 2018-1-14
###Added
- Added cases for checking for attackble spaces, including diagonals
- Added print methods to help visualize the board with rows a-h and col 1-8
- Tested out the board and the 92 solutions using a 1D array
- Wrote out the methods for placing the queens on the board and the recursive method that would work with placing the queens and checking if they can be placed on certain areas
	
## 0.03 - 2018-1-15
###Added
-Implemented the feature to print all 92 solutions as specified by the spec with the print method
-Rewrote the print method so it works with a 2D array and prints the graphical solution and the solution in the specified format simultaneously
-Added the Solution numbers right by each number
	
## 0.04 - 2018-1-16
###Added
-Cleaned up the code, finalizing everything
-Added comments to explain the code
-Updated README.txt
-Tarballed the project
