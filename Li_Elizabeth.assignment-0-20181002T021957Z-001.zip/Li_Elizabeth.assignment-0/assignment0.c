
#include<stdio.h>
#include<stdbool.h>
#include<math.h>

int count;

//Prints the graph and solution
void printSolution(int chessBoard[8][8])
{
    int i, j;
    printf("Solution: %d\n", ++count); //Prints the solution number
    printf("\n");
    for(i = 0; i < 8; i++)
    {
        for(j = 0; j < 8; j++)
        {
        
            if(chessBoard[i][j] == 1)
            {
                 if(i == 0)
                    {
                         printf("%c", 'a');
                    }
                 else if(i == 1)
                    {
                        printf("%c", 'b');
                    }
                else if(i == 2)
                    {
                        printf("%c", 'c');
                    }
                else if(i == 3)
                    {
                        printf("%c", 'd');
                    }
                else if(i == 4)
                    {
                        printf("%c", 'e');
                    }
                else if(i == 5)
                    {
                        printf("%c", 'f');
                    }
                else if(i == 6)
                    {
                        printf("%c", 'g');
                    }
                else if(i == 7)
                    {
                        printf("%c", 'h');
                    }
                printf("%d", j+1);
            }
            
        }
    }
    printf("\n");
    
    //To just see the solutions and not the board, comment out this part from here
    for(i=1;i<=8;i++)
 {
    if(i == 1)
     {
         printf("\t%c", 'a');
     }
     else if(i == 2)
     {
         printf("\t%c", 'b');
     }
     else if(i == 3)
     {
         printf("\t%c", 'c');
     }
     else if(i == 4)
     {
         printf("\t%c", 'd');
     }
     else if(i == 5)
     {
         printf("\t%c", 'e');
     }
     else if(i == 6)
     {
         printf("\t%c", 'f');
     }
     else if(i == 7)
     {
         printf("\t%c", 'g');
     }
     else if(i == 8)
     {
         printf("\t%c", 'h');
     }
 //Printing out the row letters
 }
    for(i = 0; i < 8; i++)     //Printing the solution in form of a board
    {
         printf("\n\n%d",i + 1);
        for(j = 0; j < 8; j++)
        {
        
            if(chessBoard[j][i] == 1)
            {
	      printf("\t*"); //* indicates that a Queen is placed
            }
            else
            {
	      printf("\t-"); //- indicates that no Queen is there
            }
            
        }
        printf("\n");
	}
    //To here    
}

//Check to see if we can place the Queen on the board
int safe(int chessBoard[8][8], int row, int col)
{
    int i, j;
 
   
    for (i = 0; i < col; i++)
      {
        if (chessBoard[row][i] == 1)
	  {
            return 1;
	  }
      }
 
    for(i = 0; i < 8; i++)
    {
        for(j = 0; j < 8; j++)
        {
            if(((row + col) == (i + j)))
            {
                if(chessBoard[i][j] == 1)
                {
                    return 1;
                }
            }
	    if(((row - col) == (i-j)))
	    {
	      if(chessBoard[i][j] == 1)
		{
		  return 1;
		}
	    }

        }
    }
}
int markQueen(int chessBoard[8][8], int col)
{

    if(col == 8)
    {

	printSolution(chessBoard);
	return 0;

    }
    
    int i;
    for(i = 0; i < 8; i++)
    {
      if(safe(chessBoard, i, col) == 0)
	{
	  chessBoard[i][col] = 1;
	  markQueen(chessBoard, col+1);
	  chessBoard[i][col] = 0;
	}
    }
    return 1;
}

int main()
{
 int chessBoard[8][8] = { };
 int initialColumn = 0;
 markQueen(chessBoard, initialColumn);
 return 0;
}
