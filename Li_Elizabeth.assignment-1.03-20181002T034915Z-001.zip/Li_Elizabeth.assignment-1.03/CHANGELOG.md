Changelog

All notable changes to the project will be documented in this file


## 0.01 - 2018-1-18
### Added
-This Changefile to keep track of updates and changes to Assignment1.01
-README file to explain this week's projects and important features and functions
-Created 2D dungeon array and another 2D array to keep track of room dimensions
-Setting up rock
-Set up entering a number for number of rooms wanted, through commandline 1-5

## 0.02 - 2018-1-20
### Added
-A function for creating the rooms, called makeRooms, inputting the number that is input by the user on the commandline that sets up the rooms and their widths and heights. 


##0.03 - 2018-1-21
### Added
-A function for checking to see if making the rooms at particular areas are valid or not
-Fixed the memory issues and speeding up the functions through srand and accounting for no infinite loops
-Thought of logic behind making and printing the paths


##0.04 - 2018-1-22
### Added
-Wrote the functions for printing the paths
-Wrote makePaths, the function that builds the paths based on the number of rooms input
-Wrote buildPath, the function that actually assigns values in the arrays for making the paths
-Wrote printPath, the function for printing the paths as "#" on the screen


##0.04 - 2018-1-23
### Added
-makefile for Assignment1.01
-Eliminated repetitive code
-Updated Changelog
-Updated README
-Made the dungeon less linear by giving it a 20% chance of creating a path that is not linear.

## 0.05 - 2018-1-27
-Added professor's solution
-Deciphered it

## 0.06 -2018-1-28
-Implemented load functionality
-Implemented save functionality

## 0.07 -2018-1-29
-Added the tags to the main method to be able to run everything
-Cleaned up code
##0.08 - 2018-1-30
-Cleaned up more code
--Added readme

##0.08 -2018-2-2
-Attempted to figure out placing PC on the screen
	
##0.09 -2018-2-4
-Modified Dijkstra's methods
-Started implementing calculating the distances
##0.10 -2018-2-8
-Started implementing the renderMap function
-Played around with using the distances to get distanceMaps
##0.11 -2018-2-11
-made README
-Worked on distance and render functions to get more accurate tunneling maps
