This 1.07 Assignment implements a monster parser that parses monster
definitions, as in real rogue-like games, there is more variety to 
monsters with more complexity. Now, the monsters have: color, a
name, a description, hitpoints (health), attack damage, and a general ?abilities? field, where intelligence and
telepathy are just two possibilities. 

Given a text file full of monster descriptions with those given values and inputs,
the monster parser will take those descriptions and output them on
the console/terminal. To do so, I went ahead and commented out all
things pertaining to a dungeon in rlg327.cpp, as that is not needed for this assignment,
as all that is needed is a parser.

The only two things I added to this assignment were:
-the monster parsing implementation in parser.cpp
-parser.h

Inside parser.cpp, I added a function called parser_files()
that would go ahead and take in the monster_desc.txt file and print
off all valid values/traits for the given monsters in the text in
the order that was specified by the spec and examples in the spec.

To run the parser, just use the command "./rlg327" and to compile, call
"make all". Clean with "make clean"