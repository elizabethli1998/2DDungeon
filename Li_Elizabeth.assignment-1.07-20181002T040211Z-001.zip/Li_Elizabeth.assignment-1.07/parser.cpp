#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>


#include "move.h"
#include "path.h"
#include "event.h"
#include "pc.h"
#include "utils.h"
#include "npc.h"
#include "dungeon.h"
#include "character.h"


using namespace std;


int parser_files(){
  string line;
  ifstream myfile ("monster_desc.txt");
  string dmg = "";
  char symbol = ' ';
  int rarity = 0;
    // string rarity = "";
  string r = "";
  string name = "";
  string description = "";
  string color = "";
  string spd = "";
  string abilities = "";
  string  hp = "";

  if (myfile.is_open())
  {getline(myfile, line);
    if(line.compare("RLG327 MONSTER DESCRIPTION 1") != 0)
      {
        cout << "Incorrect file header";
        return -1;
      }
    while ( getline (myfile,line) )
    {if(line.compare("BEGIN MONSTER"))
	{while(line.compare("END") != 0)
	  {getline(myfile, line);
          if(line.substr(0,4) == "NAME")
	    { name = line.substr(5);}
	  else if(line.substr(0,4) == "DESC")
	    { getline(myfile, line);
            while(line.compare(".") != 0)
	      { description += line + "\n";
		getline(myfile, line);
	      }
          }
	  else if(line.substr(0,4) == "SYMB")
	    {symbol = line[5];}
	  else if(line.substr(0,5) == "COLOR")
	    {color = line.substr(6);}
           else if(line.substr(0,5) == "SPEED")
	     {spd = line.substr(6);}
          else if(line.substr(0,4) == "ABIL")
	    {abilities = line.substr(5);}
	  else if(line.substr(0,2) == "HP")
	    {hp = line.substr(3);}
	  else if(line.substr(0,3) == "DAM")
	    {dmg = line.substr(4);}
	  else if(line.substr(0,4) == "RRTY")
	    {
	      std::string r = line.substr(5);
	      rarity = atoi(r.c_str());
	      // rarity = line.substr(5);
	    }    
        }
        cout << name << endl;
        cout << description << endl;
	cout << symbol << endl;
        cout << color << endl;
       	cout << spd << endl;
        cout << abilities << endl;
	cout << hp << endl;
	cout << dmg << endl;
	if(rarity != 0)
	  {
	    cout << rarity << endl;
	  }
	else
	  {
	    cout << "";
	  }
        cout << endl;
        color = "";
        spd = "";
        abilities = "";
        hp = "";
        dmg = "";
	rarity = 0;
        name = "";
        description = "";
	symbol = ' '; 
      }

    }
    myfile.close();
  }
  else cout << "Failed to open file";
  return 0;
}
