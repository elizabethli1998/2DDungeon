#ifndef PARSER_H
# define PARSER_H

# include <stdint.h>
# include <string>

# include "dims.h"

int parser_files();

#endif
