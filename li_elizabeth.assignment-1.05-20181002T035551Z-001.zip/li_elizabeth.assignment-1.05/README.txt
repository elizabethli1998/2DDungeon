 

This 1.05 Assignment implements NCurses interface and allows the player to control the PC movement. Monsters now have their
individual traits shown as a number/letter to make them more identifiable. Player controls PC movement with a set
list of controls, entered by keys and is shown on terminal. This game waits for the user to provide input and 
will continue the game until the PC dies, wins, or quits the game with the "Q" key. Player can also now go up the stairs
that are located in the dungeon and going up them will take them to a new map, aka the floor in the dungeon.

-main method now puts everything that I've added together. It implements the stairs feature, being able to quit
the game, and implements the user input to control the player character.
-render_dungeon now uses ncurses and shows the keys for the commands. 
-pc_next_pos function now relies on the Player input based on what key is pressed. Player can also quit the game
or go up the stairs using the Q or the "<" or ">" respectively.
-Dungeon Struct now keeps track of location of stairs and whether the stairs take the Player up 
or down. Stairs are now randomly placed in the rooms. Whether or not the stairs go up or down have a 50% chance
of either case. In pc.c, this particular functionality for stairs is implemented.
