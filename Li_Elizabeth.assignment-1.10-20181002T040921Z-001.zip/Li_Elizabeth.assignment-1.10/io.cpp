#include <unistd.h>
#include <ncurses.h>
#include <ctype.h>
#include <stdlib.h>
#include <sys/time.h>
#include <signal.h>
#include <curses.h>
#include <cstring>

#include "io.h"
#include "move.h"
#include "path.h"
#include "pc.h"
#include "utils.h"
#include "dungeon.h"
#include "object.h"
#include "npc.h"

/* Same ugly hack we did in path.c */
static dungeon_t *dungeon;

typedef struct io_message {
    /* Will print " --more-- " at end of line when another message follows. *
     * Leave 10 extra spaces for that.                                      */
    char msg[71];
    struct io_message *next;
} io_message_t;

static io_message_t *io_head, *io_tail;
uint32_t io_print_spells(dungeon_t *d);
int io_print_shop(dungeon_t *d);

void io_init_terminal(dungeon_t *d)
{
    initscr();
    raw();
    noecho();
    curs_set(0);
    keypad(stdscr, TRUE);
    start_color();
    init_pair(COLOR_RED, COLOR_RED, COLOR_BLACK);
    init_pair(COLOR_GREEN, COLOR_GREEN, COLOR_BLACK);
    init_pair(COLOR_YELLOW, COLOR_YELLOW, COLOR_BLACK);
    init_pair(COLOR_BLUE, COLOR_BLUE, COLOR_BLACK);
    init_pair(COLOR_MAGENTA, COLOR_MAGENTA, COLOR_BLACK);
    init_pair(COLOR_CYAN, COLOR_CYAN, COLOR_BLACK);
    init_pair(COLOR_WHITE, COLOR_WHITE, COLOR_BLACK);
    // HP
    init_pair(COLOR_HP, COLOR_WHITE, COLOR_RED);
    // MP
    init_pair(COLOR_MP, COLOR_WHITE, COLOR_BLUE);
    dungeon = d;
}

void io_reset_terminal(void)
{
    endwin();

    while (io_head) {
        io_tail = io_head;
        io_head = io_head->next;
        free(io_tail);
    }
    io_tail = NULL;
}

void io_queue_message(const char *format, ...)
{
    io_message_t *tmp;
    va_list ap;

    if (!(tmp = (io_message_t *) malloc(sizeof (*tmp)))) {
        perror("malloc");
        exit(1);
    }

    tmp->next = NULL;

    va_start(ap, format);

    vsnprintf(tmp->msg, sizeof (tmp->msg), format, ap);

    va_end(ap);

    if (!io_head) {
        io_head = io_tail = tmp;
    } else {
        io_tail->next = tmp;
        io_tail = tmp;
    }
}

static void io_print_message_queue(uint32_t y, uint32_t x)
{
    while (io_head) {
        io_tail = io_head;
        attron(COLOR_PAIR(COLOR_CYAN));
        mvprintw(y, x, "%-80s", io_head->msg);
        attroff(COLOR_PAIR(COLOR_CYAN));
        io_head = io_head->next;
        attron(COLOR_PAIR(COLOR_CYAN));
        mvprintw(y, x + 70, "%10s", " --more-- ");
        attroff(COLOR_PAIR(COLOR_CYAN));
        refresh();
        getch();
        free(io_tail);
    }
    io_tail = NULL;
}

static char distance_to_char[] = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

void io_display_ch(dungeon_t *d)
{
    mvprintw(11, 33, " HP:    %5d ", d->the_pc->hp);
    mvprintw(12, 33, " Speed: %5d ", d->the_pc->speed);
    mvprintw(14, 27, " Hit any key to continue. ");
    refresh();
    getch();
}

void io_display_tunnel(dungeon_t *d)
{
    uint32_t y, x;
    clear();
    for (y = 0; y < DUNGEON_Y; y++) {
        for (x = 0; x < DUNGEON_X; x++) {
            mvaddch(y + 1, x, (d->pc_tunnel[y][x] < 62              ?
                               distance_to_char[d->pc_tunnel[y][x]] :
                               '*'));
        }
    }
    refresh();
    while (getch() != 27 /* ESC */)
        ;
  
}

void io_display_distance(dungeon_t *d)
{
    uint32_t y, x;
    clear();
    for (y = 0; y < DUNGEON_Y; y++) {
        for (x = 0; x < DUNGEON_X; x++) {
            mvaddch(y + 1, x, (d->pc_distance[y][x] < 62              ?
                               distance_to_char[d->pc_distance[y][x]] :
                               '*'));
        }
    }
    refresh();
    while (getch() != 27 /* ESC */)
        ;
 
}

void io_display_hardness(dungeon_t *d)
{
    uint32_t y, x;

    for (y = 0; y < DUNGEON_Y; y++) {
        for (x = 0; x < DUNGEON_X; x++) {
            /* Maximum hardness is 255.  We have 62 values to display it, but *
             * we only want one zero value, so we need to cover [1,255] with  *
             * 61 values, which gives us a divisor of 254 / 61 = 4.164.       *
             * Generally, we want to avoid floating point math, but this is   *
             * not gameplay, so we'll make an exception here to get maximal   *
             * hardness display resolution.                                   */
            mvaddch(y + 1, x, (d->hardness[y][x]                             ?
                               distance_to_char[1 + (d->hardness[y][x] / 5)] :
                               '0'));
        }
    }
    refresh();
 
}
static void io_redisplay_visible_monsters(dungeon_t *d)
{
  /* This was initially supposed to only redisplay visible monsters.  After *
   * implementing that (comparitivly simple) functionality and testing, I   *
   * discovered that it resulted to dead monsters being displayed beyond    *
   * their lifetimes.  So it became necessary to implement the function for *
   * everything in the light radius.  In hindsight, it would be better to   *
   * keep a static array of the things in the light radius, generated in    *
   * io_display() and referenced here to accelerate this.  The whole point  *
   * of this is to accelerate the rendering of multi-colored monsters, and  *
   * it is *significantly* faster than that (it eliminates flickering       *
   * artifacts), but it's still significantly slower than it could be.  I   *
   * will revisit this in the future to add the acceleration matrix.        */
  pair_t pos;
  uint32_t color;
  uint32_t illuminated;

  for (pos[dim_y] = -PC_VISUAL_RANGE;
       pos[dim_y] <= PC_VISUAL_RANGE;
       pos[dim_y]++) {
    for (pos[dim_x] = -PC_VISUAL_RANGE;
         pos[dim_x] <= PC_VISUAL_RANGE;
         pos[dim_x]++) {
      if ((d->the_pc->position[dim_y] + pos[dim_y] < 0) ||
          (d->the_pc->position[dim_y] + pos[dim_y] >= DUNGEON_Y) ||
          (d->the_pc->position[dim_x] + pos[dim_x] < 0) ||
          (d->the_pc->position[dim_x] + pos[dim_x] >= DUNGEON_X)) {
        continue;
      }
      if ((illuminated = is_illuminated(d->the_pc,
                                        d->the_pc->position[dim_y] + pos[dim_y],
                                        d->the_pc->position[dim_x] + pos[dim_x]))) {
        attron(A_BOLD);
      }
      if (d->charmap[d->the_pc->position[dim_y] + pos[dim_y]]
                          [d->the_pc->position[dim_x] + pos[dim_x]] &&
          can_see(d, d->the_pc->position,
                  d->charmap[d->the_pc->position[dim_y] + pos[dim_y]]
                                  [d->the_pc->position[dim_x] +
                                   pos[dim_x]]->position, 1)) {
        attron(COLOR_PAIR((color = d->charmap[d->the_pc->position[dim_y] +
                                                    pos[dim_y]]
                                                   [d->the_pc->position[dim_x] +
                                                    pos[dim_x]]->get_color())));
        mvaddch(d->the_pc->position[dim_y] + pos[dim_y] + 1,
                d->the_pc->position[dim_x] + pos[dim_x],
                character_get_symbol(d->charmap[d->the_pc->position[dim_y] +
                                                      pos[dim_y]]
                                                     [d->the_pc->position[dim_x] +
                                                      pos[dim_x]]));
        attroff(COLOR_PAIR(color));
      } else if (d->objmap[d->the_pc->position[dim_y] + pos[dim_y]]
                          [d->the_pc->position[dim_x] + pos[dim_x]] &&
                 (can_see(d, d->the_pc->position,
                          d->objmap[d->the_pc->position[dim_y] + pos[dim_y]]
                                   [d->the_pc->position[dim_x] +
                                    pos[dim_x]]->get_position(), 1) ||
                 d->objmap[d->the_pc->position[dim_y] + pos[dim_y]]
                          [d->the_pc->position[dim_x] + pos[dim_x]]->have_seen())) {
        attron(COLOR_PAIR(d->objmap[d->the_pc->position[dim_y] + pos[dim_y]]
                                   [d->the_pc->position[dim_x] +
                                    pos[dim_x]]->get_color()));
        mvaddch(d->the_pc->position[dim_y] + pos[dim_y] + 1,
                d->the_pc->position[dim_x] + pos[dim_x],
                d->objmap[d->the_pc->position[dim_y] + pos[dim_y]]
                         [d->the_pc->position[dim_x] + pos[dim_x]]->get_symbol());
        attroff(COLOR_PAIR(d->objmap[d->the_pc->position[dim_y] + pos[dim_y]]
                                    [d->the_pc->position[dim_x] +
                                     pos[dim_x]]->get_color()));
      } else {
        switch (pc_learned_terrain(d->the_pc,
                                   d->the_pc->position[dim_y] + pos[dim_y],
                                   d->the_pc->position[dim_x] +
                                   pos[dim_x])) {
        case ter_wall:
        case ter_wall_immutable:
        case ter_unknown:
          mvaddch(d->the_pc->position[dim_y] + pos[dim_y] + 1,
                  d->the_pc->position[dim_x] + pos[dim_x], ' ');
          break;
        case ter_floor:
        case ter_floor_room:
          mvaddch(d->the_pc->position[dim_y] + pos[dim_y] + 1,
                  d->the_pc->position[dim_x] + pos[dim_x], '.');
          break;
        case ter_floor_hall:
          mvaddch(d->the_pc->position[dim_y] + pos[dim_y] + 1,
                  d->the_pc->position[dim_x] + pos[dim_x], '#');
          break;
        case ter_debug:
          mvaddch(d->the_pc->position[dim_y] + pos[dim_y] + 1,
                  d->the_pc->position[dim_x] + pos[dim_x], '*');
          break;
        case ter_stairs_up:
          mvaddch(d->the_pc->position[dim_y] + pos[dim_y] + 1,
                  d->the_pc->position[dim_x] + pos[dim_x], '<');
          break;
        case ter_stairs_down:
          mvaddch(d->the_pc->position[dim_y] + pos[dim_y] + 1,
                  d->the_pc->position[dim_x] + pos[dim_x], '>');
          break;
        default:
 /* Use zero as an error symbol, since it stands out somewhat, and it's *
  * not otherwise used.                                                 */
          mvaddch(d->the_pc->position[dim_y] + pos[dim_y] + 1,
                  d->the_pc->position[dim_x] + pos[dim_x], '0');
        }
      }
      attroff(A_BOLD);
    }
  }

  refresh();
}

/*
static character *io_nearest_visible_monster(dungeon *d)
{
  character **c, *n;
  uint32_t x, y, count, i;

  c = (character **) malloc(d->num_monsters * sizeof (*c));

  Get a linear list of monsters 
  for (count = 0, y = 1; y < DUNGEON_Y - 1; y++) {
    for (x = 1; x < DUNGEON_X - 1; x++) {
     if (d->character_map[y][x] && d->character_map[y][x] != d->PC) {
        c[count++] = d->character_map[y][x];
      }
    }
  }

  Sort it by distance from PC 
  the_dungeon = d;
  qsort(c, count, sizeof (*c), compare_monster_distance);

  for (n = NULL, i = 0; i < count; i++) {
    if (can_see(d, character_get_pos(d->PC), character_get_pos(c[i]), 1, 0)) {
      n = c[i];
      break;
    }
  }

  free(c);

  return n;
  }*/


void io_display_all(dungeon_t *d)
{
    uint32_t y, x;

  
    clear();
    for (y = 0; y < DUNGEON_Y; y++) {
        for (x = 0; x < DUNGEON_X; x++) {
            if (d->charmap[y][x]) {
                attron(COLOR_PAIR(d->charmap[y][x]->get_color()));
                mvaddch(y + 1, x, d->charmap[y][x]->get_symbol());
                attroff(COLOR_PAIR(d->charmap[y][x]->get_color()));
            } else if (d->objmap[y][x] && d->objmap[y][x]->have_seen()) {
                attron(COLOR_PAIR(d->objmap[y][x]->get_color()));
                mvaddch(y + 1, x, d->objmap[y][x]->get_symbol());
                attroff(COLOR_PAIR(d->objmap[y][x]->get_color()));
            } else {
                switch (mapxy(x, y)) {
                    case ter_wall:
                    case ter_wall_immutable:
                        mvaddch(y + 1, x, ' ');
                        break;
                    case ter_floor:
                    case ter_floor_room:
                        mvaddch(y + 1, x, '.');
                        break;
                    case ter_floor_hall:
                        mvaddch(y + 1, x, '#');
                        break;
                    case ter_debug:
                        mvaddch(y + 1, x, '*');
                        break;
                    case ter_stairs_up:
                        mvaddch(y + 1, x, '<');
                        break;
                    case ter_stairs_down:
                        mvaddch(y + 1, x, '>');
                        break;
                    default:
                        /* Use zero as an error symbol, since it stands out somewhat, and it's *
                         * not otherwise used.                                                 */
                        mvaddch(y + 1, x, '0');
                }
            }
        }
    }

    io_print_message_queue(0, 0);

    refresh();
    getch();
 
}


void io_display(dungeon_t *d)
{
    uint32_t y, x;
    uint32_t illuminated;

    clear();
    for (y = 0; y < DUNGEON_Y; y++) {
        for (x = 0; x < DUNGEON_X; x++) {
            if ((illuminated = is_illuminated(d->the_pc, y, x))) {
                attron(A_BOLD);
            }
            if (d->charmap[y][x] &&
                can_see(d,
                        character_get_pos(d->the_pc),
                        character_get_pos(d->charmap[y][x]),
                        1)) {
                attron(COLOR_PAIR(d->charmap[y][x]->get_color()));
                mvaddch(y + 1, x, d->charmap[y][x]->get_symbol());
                attroff(COLOR_PAIR(d->charmap[y][x]->get_color()));
            } else if (d->objmap[y][x] && d->objmap[y][x]->have_seen()) {
                attron(COLOR_PAIR(d->objmap[y][x]->get_color()));
                mvaddch(y + 1, x, d->objmap[y][x]->get_symbol());
                attroff(COLOR_PAIR(d->objmap[y][x]->get_color()));
            } else {
                switch (pc_learned_terrain(d->the_pc, y, x)) {
                    case ter_wall:
                    case ter_wall_immutable:
                    case ter_unknown:
                        mvaddch(y + 1, x, ' ');
                        break;
                    case ter_floor:
                    case ter_floor_room:
                        mvaddch(y + 1, x, '.');
                        break;
                    case ter_floor_hall:
                        mvaddch(y + 1, x, '#');
                        break;
                    case ter_debug:
                        mvaddch(y + 1, x, '*');
                        break;
                    case ter_stairs_up:
                        mvaddch(y + 1, x, '<');
                        break;
                    case ter_stairs_down:
                        mvaddch(y + 1, x, '>');
                        break;
                    default:
                        /* Use zero as an error symbol, since it stands out somewhat, and it's *
                         * not otherwise used.                                                 */
                        mvaddch(y + 1, x, '0');
                }
            }
            if (illuminated) {
                attroff(A_BOLD);
            }
        }
    }

    io_print_hud(d);
    io_print_message_queue(0, 0);

    refresh();
    
}
static void io_redisplay_non_terrain(dungeon_t *d, pair_t cursor)
{
  /* For the wiz-mode teleport, in order to see color-changing effects. */
  pair_t pos;
  uint32_t color;
  uint32_t illuminated;

  for (pos[dim_y] = 0; pos[dim_y] < DUNGEON_Y; pos[dim_y]++) {
    for (pos[dim_x] = 0; pos[dim_x] < DUNGEON_X; pos[dim_x]++) {
      if ((illuminated = is_illuminated(d->the_pc,
                                        pos[dim_y],
                                        pos[dim_x]))) {
        attron(A_BOLD);
      }
      if (cursor[dim_y] == pos[dim_y] && cursor[dim_x] == pos[dim_x]) {
        mvaddch(pos[dim_y] + 1, pos[dim_x], '*');
      } else if (d->charmap[pos[dim_y]][pos[dim_x]]) {
        attron(COLOR_PAIR((color = d->charmap[pos[dim_y]]
                                                   [pos[dim_x]]->get_color())));
        mvaddch(pos[dim_y] + 1, pos[dim_x],
                character_get_symbol(d->charmap[pos[dim_y]][pos[dim_x]]));
        attroff(COLOR_PAIR(color));
      } else if (d->objmap[pos[dim_y]][pos[dim_x]]) {
        attron(COLOR_PAIR(d->objmap[pos[dim_y]][pos[dim_x]]->get_color()));
        mvaddch(pos[dim_y] + 1, pos[dim_x],
                d->objmap[pos[dim_y]][pos[dim_x]]->get_symbol());
        attroff(COLOR_PAIR(d->objmap[pos[dim_y]][pos[dim_x]]->get_color()));
      }
      attroff(A_BOLD);
    }
  }

  refresh();
}

void io_display_no_fog(dungeon_t *d)
{
  uint32_t y, x;
  uint32_t color;

  clear();
  for (y = 0; y < DUNGEON_Y; y++) {
    for (x = 0; x < DUNGEON_X; x++) {
      if (d->charmap[y][x]) {
        attron(COLOR_PAIR((color = d->charmap[y][x]->get_color())));
        mvaddch(y + 1, x, character_get_symbol(d->charmap[y][x]));
        attroff(COLOR_PAIR(color));
      } else if (d->objmap[y][x]) {
        attron(COLOR_PAIR(d->objmap[y][x]->get_color()));
        mvaddch(y + 1, x, d->objmap[y][x]->get_symbol());
        attroff(COLOR_PAIR(d->objmap[y][x]->get_color()));
      } else {
        switch (mapxy(x, y)) {
        case ter_wall:
        case ter_wall_immutable:
          mvaddch(y + 1, x, ' ');
          break;
        case ter_floor:
        case ter_floor_room:
          mvaddch(y + 1, x, '.');
          break;
        case ter_floor_hall:
          mvaddch(y + 1, x, '#');
          break;
        case ter_debug:
          mvaddch(y + 1, x, '*');
          break;
        case ter_stairs_up:
          mvaddch(y + 1, x, '<');
          break;
        case ter_stairs_down:
          mvaddch(y + 1, x, '>');
          break;
        default:
 /* Use zero as an error symbol, since it stands out somewhat, and it's *
  * not otherwise used.                                                 */
          mvaddch(y + 1, x, '0');
        }
      }
    }
  }

}
void io_display_monster_list(dungeon_t *d)
{
    mvprintw(11, 33, " HP:    XXXXX ");
    mvprintw(12, 33, " Speed: XXXXX ");
    mvprintw(14, 27, " Hit any key to continue. ");
    refresh();
    getch();
}

uint32_t io_teleport_pc(dungeon_t *d)
{

  pair_t dest;
  int c;
  fd_set readfs;
  struct timeval tv;

  io_display_all(d);

  mvprintw(0, 0, "Choose a location.  't' to teleport to; 'r' for random.");

  dest[dim_y] = d->the_pc->position[dim_y];
  dest[dim_x] = d->the_pc->position[dim_x];

 mvaddch(dest[dim_y] + 1, dest[dim_x], '*');
  refresh();

 do {
    do{
      FD_ZERO(&readfs);
      FD_SET(STDIN_FILENO, &readfs);

      tv.tv_sec = 0;
      tv.tv_usec = 125000; /* An eigth of a second */

      io_redisplay_non_terrain(d, dest);
    } while (!select(STDIN_FILENO + 1, &readfs, NULL, NULL, &tv));
    /* Can simply draw the terrain when we move the cursor away, *
     * because if it is a character or object, the refresh       *
     * function will fix it for us.                              */
    switch (mappair(dest)) {
    case ter_wall:
    case ter_wall_immutable:
    case ter_unknown:
      mvaddch(dest[dim_y] + 1, dest[dim_x], ' ');
      break;
    case ter_floor:
    case ter_floor_room:
      mvaddch(dest[dim_y] + 1, dest[dim_x], '.');
      break;
    case ter_floor_hall:
      mvaddch(dest[dim_y] + 1, dest[dim_x], '#');
      break;
    case ter_debug:
      mvaddch(dest[dim_y] + 1, dest[dim_x], '*');
      break;
    case ter_stairs_up:
      mvaddch(dest[dim_y] + 1, dest[dim_x], '<');
      break;
    case ter_stairs_down:
      mvaddch(dest[dim_y] + 1, dest[dim_x], '>');
      break;
    default:
 /* Use zero as an error symbol, since it stands out somewhat, and it's *
  * not otherwise used.                                                 */
      mvaddch(dest[dim_y] + 1, dest[dim_x], '0');
    }
    switch ((c = getch())) {
    case '7':
    case 'y':
    case KEY_HOME:
      if (dest[dim_y] != 1) {
        dest[dim_y]--;
      }
      if (dest[dim_x] != 1) {
        dest[dim_x]--;
      }
      break;
    case '8':
    case 'k':
    case KEY_UP:
      if (dest[dim_y] != 1) {
        dest[dim_y]--;
      }
      break;
    case '9':
    case 'u':
    case KEY_PPAGE:
      if (dest[dim_y] != 1) {
        dest[dim_y]--;
      }
      if (dest[dim_x] != DUNGEON_X - 2) {
        dest[dim_x]++;
      }
      break;
    case '6':
    case 'l':
    case KEY_RIGHT:
      if (dest[dim_x] != DUNGEON_X - 2) {
        dest[dim_x]++;
      }
      break;
    case '3':
    case 'n':
    case KEY_NPAGE:
      if (dest[dim_y] != DUNGEON_Y - 2) {
        dest[dim_y]++;
      }
      if (dest[dim_x] != DUNGEON_X - 2) {
        dest[dim_x]++;
      }
      break;
    case '2':
    case 'j':
    case KEY_DOWN:
      if (dest[dim_y] != DUNGEON_Y - 2) {
        dest[dim_y]++;
      }
      break;
    case '1':
    case 'b':
    case KEY_END:
      if (dest[dim_y] != DUNGEON_Y - 2) {
        dest[dim_y]++;
      }
      if (dest[dim_x] != 1) {
        dest[dim_x]--;
      }
      break;
    case '4':
    case 'h':
    case KEY_LEFT:
      if (dest[dim_x] != 1) {
        dest[dim_x]--;
      }
      break;
    }
  } while (c != 't' && c != 'r');

  if (c == 'r') {
    do {
      dest[dim_x] = rand_range(1, DUNGEON_X - 2);
      dest[dim_y] = rand_range(1, DUNGEON_Y - 2);
    } while (charpair(dest) || mappair(dest) < ter_floor);
  }

  if (charpair(dest) && charpair(dest) != d->the_pc) {
    io_queue_message("Teleport failed.  Destination occupied.");
  } else {  
    d->charmap[d->the_pc->position[dim_y]][d->the_pc->position[dim_x]] = NULL;
    d->charmap[dest[dim_y]][dest[dim_x]] = d->the_pc;

    d->the_pc->position[dim_y] = dest[dim_y];
    d->the_pc->position[dim_x] = dest[dim_x];
  }

  pc_observe_terrain(d->the_pc, d);
  dijkstra(d);
  dijkstra_tunnel(d);

  io_display(d);

  return 0;
}

/* Adjectives to describe our monsters */
static const char *adjectives[] = {
        "A menacing ",
        "A threatening ",
        "A horrifying ",
        "An intimidating ",
        "An aggressive ",
        "A frightening ",
        "A terrifying ",
        "A terrorizing ",
        "An alarming ",
        "A frightening ",
        "A dangerous ",
        "A glowering ",
        "A glaring ",
        "A scowling ",
        "A chilling ",
        "A scary ",
        "A creepy ",
        "An eerie ",
        "A spooky ",
        "A slobbering ",
        "A drooling ",
        " A horrendous ",
        "An unnerving ",
        "A cute little ",  /* Even though they're trying to kill you, */
        "A teeny-weenie ", /* they can still be cute!                 */
        "A fuzzy ",
        "A fluffy white ",
        "A kawaii ",       /* For our otaku */
        "Hao ke ai de "    /* And for our Chinese */
        /* And there's one special case (see below) */
};

static void io_scroll_monster_list(char (*s)[40], uint32_t count)
{
    uint32_t offset;
    uint32_t i;

    offset = 0;

    while (1) {
        for (i = 0; i < 13; i++) {
            mvprintw(i + 6, 19, " %-40s ", s[i + offset]);
        }
        switch (getch()) {
            case KEY_UP:
                if (offset) {
                    offset--;
                }
                break;
            case KEY_DOWN:
                if (offset < (count - 13)) {
                    offset++;
                }
                break;
            case 27:
                return;
        }

    }
}
/*
static bool is_vowel(const char c)
{
    return (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
            c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U');
}
*/

static void io_list_monsters_display(dungeon_t *d,
                                     character **c,
                                     uint32_t count)
{
    uint32_t i;
    char (*s)[40]; /* pointer to array of 40 char */

    (void) adjectives;

    s = (char (*)[40]) malloc((count ? count : 1) * sizeof (*s));

    mvprintw(3, 19, " %-40s ", "");
    /* Borrow the first element of our array for this string: */
    snprintf(s[0], 40, "You know of %d monsters:", count);
    mvprintw(4, 19, " %-40s ", s);
    mvprintw(5, 19, " %-40s ", "");

    for (i = 0; i < count; i++) {
        snprintf(s[i], 40, "A Lv.%u %s (%c): %2d %s by %2d %s",
                 character_get_level(c[i]),
                 character_get_name(c[i]),
                 character_get_symbol(c[i]),
                 abs(character_get_y(c[i]) - character_get_y(d->the_pc)),
                 ((character_get_y(c[i]) - character_get_y(d->the_pc)) <= 0 ?
                  "N" : "S"),
                 abs(character_get_x(c[i]) - character_get_x(d->the_pc)),
                 ((character_get_x(c[i]) - character_get_x(d->the_pc)) <= 0 ?
                  "E" : "W"));
        if (count <= 13) {
            /* Handle the non-scrolling case right here. *
             * Scrolling in another function.            */
            mvprintw(i + 6, 19, " %-40s ", s[i]);
        }
    }

    if (count <= 13) {
        mvprintw(count + 6, 19, " %-40s ", "");
        mvprintw(count + 7, 19, " %-40s ", "Hit escape to continue.");
        while (getch() != 27 /* escape */)
            ;
    } else {
        mvprintw(19, 19, " %-40s ", "");
        mvprintw(20, 19, " %-40s ",
                 "Arrows to scroll, escape to continue.");
        io_scroll_monster_list(s, count);
    }

    free(s);
}

static int compare_monster_distance(const void *v1, const void *v2)
{
    const character *const *c1 = (const character * const *) v1;
    const character *const *c2 = (const character * const *) v2;

    return (dungeon->pc_distance[character_get_y(*c1)][character_get_x(*c1)] -
            dungeon->pc_distance[character_get_y(*c2)][character_get_x(*c2)]);
}

static void io_list_monsters(dungeon_t *d)
{
    character **c;
    uint32_t x, y, count;

   
    c = (character **) malloc(d->num_monsters * sizeof (*c));

    /* Get a linear list of monsters */
    for (count = 0, y = 1; y < DUNGEON_Y - 1; y++) {
        for (x = 1; x < DUNGEON_X - 1; x++) {
            if (d->charmap[y][x] &&
                d->charmap[y][x] != d->the_pc &&
                can_see(d, d->the_pc->position, character_get_pos(d->charmap[y][x]), 1)) {
                c[count++] = d->charmap[y][x];
            }
        }
    }

    /* Sort it by distance from PC */
    dungeon = d;
    qsort(c, count, sizeof (*c), compare_monster_distance);

    /* Display it */
    io_list_monsters_display(d, c, count);
    free(c);

    /* And redraw the dungeon */
    io_display(d);
}

void io_object_to_string(object *o, char *s, uint32_t size)
{
    if (o) {
        snprintf(s, size, "%s Lv:%u (sp: %d, dmg: %d+%dd%d) %dg",
                 o->get_name(), o->get_level(), o->get_speed(), o->get_damage_base(),
                 o->get_damage_number(), o->get_damage_sides(), o->get_value());
    } else {
        *s = '\0';
    }
}

uint32_t io_wear_eq(dungeon_t *d)
{
    uint32_t i, key;
    char s[61];

  
    for (i = 0; i < MAX_INVENTORY; i++) {
        /* We'll write 12 lines, 10 of inventory, 1 blank, and 1 prompt. *
         * We'll limit width to 60 characters, so very long object names *
         * will be truncated.  In an 80x24 terminal, this gives offsets  *
         * at 10 x and 6 y to start printing things.  Same principal in  *
         * other functions, below.                                       */
        io_object_to_string(d->the_pc->in[i], s, 61);
        mvprintw(i + 6, 10, " %c) %-55s ", '0' + i, s);
    }
    mvprintw(16, 10, " %-58s ", "Potions: (h)ealth and (m)ana");
    mvprintw(17, 10, " %-58s ", "Wear which item (ESC to cancel)?");
    refresh();

    while (1) {
        if ((key = getch()) == 27 /* ESC */) {
            io_display(d);
           
            return 1;
        }

        if ((key < '0' || key > '9') && !(key == 'm' || key == 'h')) {
            if (isprint(key)) {
                snprintf(s, 61, "Invalid input: '%c'.  Enter 0-9 or ESC to cancel.",
                         key);
                mvprintw(18, 10, " %-58s ", s);
            } else {
                mvprintw(18, 10, " %-58s ",
                         "Invalid input.  Enter 0-9, h/m or ESC to cancel.");
            }
            refresh();
            continue;
        }

        if(key == 'm' && d->the_pc->mana_potions > 0){
            d->the_pc->mp + 200 > PC_MP ?
                    d->the_pc->mp = PC_MP : d->the_pc->mp += 200;
            d->the_pc->mana_potions--;
            continue;
        } else if(key == 'h' && d->the_pc->hp_potions > 0){
            d->the_pc->mp + 100 > PC_HP ?
                    d->the_pc->mp = PC_HP : d->the_pc->mp += 100;
            d->the_pc->hp_potions--;
            continue;
        } else if (!d->the_pc->in[key - '0']) {
            mvprintw(18, 10, " %-58s ", "Empty inventory slot.  Try again.");
            continue;
        } else if (!d->the_pc->wear_in(key - '0')) {
            
            return 0;
        }

        snprintf(s, 61, "Can't wear %s.  Try again.",
                 d->the_pc->in[key - '0']->get_name());
        mvprintw(18, 10, " %-58s ", s);
        refresh();
    }

    return 1;
}

void io_display_in(dungeon_t *d)
{
    uint32_t i;
    char s[61];

    for (i = 0; i < MAX_INVENTORY; i++) {
        io_object_to_string(d->the_pc->in[i], s, 61);
        mvprintw(i + 7, 10, " %c) %-55s ", '0' + i, s);
    }

    mvprintw(17, 10, " %-58s ", "");
    mvprintw(18, 10, " %-58s ", "Hit any key to continue.");

    refresh();

    getch();


    io_display(d);
}

uint32_t io_remove_eq(dungeon_t *d)
{
    uint32_t i, key;
    char s[61], t[61];

    
    for (i = 0; i < num_eq_slots; i++) {
        sprintf(s, "[%s]", eq_slot_name[i]);
        io_object_to_string(d->the_pc->eq[i], t, 61);
        mvprintw(i + 5, 10, " %c %-9s) %-45s ", 'a' + i, s, t);
    }
    mvprintw(17, 10, " %-58s ", "");
    mvprintw(18, 10, " %-58s ", "Take off which item (ESC to cancel)?");
    refresh();

    while (1) {
        if ((key = getch()) == 27 /* ESC */) {
            io_display(d);
            return 1;
        }

        if (key < 'a' || key > 'l') {
            if (isprint(key)) {
                snprintf(s, 61, "Invalid input: '%c'.  Enter a-l or ESC to cancel.",
                         key);
                mvprintw(18, 10, " %-58s ", s);
            } else {
                mvprintw(18, 10, " %-58s ",
                         "Invalid input.  Enter a-l or ESC to cancel.");
            }
            refresh();
            continue;
        }

        if (!d->the_pc->eq[key - 'a']) {
            mvprintw(18, 10, " %-58s ", "Empty equipment slot.  Try again.");
            continue;
        }

        if (!d->the_pc->remove_eq(key - 'a')) {
        
            return 0;
        }

        snprintf(s, 61, "Can't take off %s.  Try again.",
                 d->the_pc->eq[key - 'a']->get_name());
        mvprintw(19, 10, " %-58s ", s);
    }
;
    return 1;
}

void io_display_eq(dungeon_t *d)
{
    uint32_t i;
    char s[61], t[61];

    for (i = 0; i < num_eq_slots; i++) {
        sprintf(s, "[%s]", eq_slot_name[i]);
        io_object_to_string(d->the_pc->eq[i], t, 61);
        mvprintw(i + 5, 10, " %c %-9s) %-45s ", 'a' + i, s, t);
    }
    mvprintw(17, 10, " %-58s ", "");
    mvprintw(18, 10, " %-58s ", "Hit any key to continue.");

    refresh();

    getch();

    io_display(d);
   
}

uint32_t io_drop_in(dungeon_t *d)
{
    uint32_t i, key;
    char s[61];

  
    for (i = 0; i < MAX_INVENTORY; i++) {
     
        mvprintw(i + 6, 10, " %c) %-55s ", '0' + i,
                 d->the_pc->in[i] ? d->the_pc->in[i]->get_name() : "");
    }
    mvprintw(16, 10, " %-58s ", "");
    mvprintw(17, 10, " %-58s ", "Drop which item (ESC to cancel)?");
    refresh();

    while (1) {
        if ((key = getch()) == 27 /* ESC */) {
            io_display(d);
          
            return 1;
        }

        if (key < '0' || key > '9') {
            if (isprint(key)) {
                snprintf(s, 61, "Invalid input: '%c'.  Enter 0-9 or ESC to cancel.",
                         key);
                mvprintw(18, 10, " %-58s ", s);
            } else {
                mvprintw(18, 10, " %-58s ",
                         "Invalid input.  Enter 0-9 or ESC to cancel.");
            }
            refresh();
            continue;
        }

        if (!d->the_pc->in[key - '0']) {
            mvprintw(18, 10, " %-58s ", "Empty inventory slot.  Try again.");
            continue;
        }

        if (!d->the_pc->drop_in(d, key - '0')) {
           
            return 0;
        }

        snprintf(s, 61, "Can't drop %s.  Try again.",
                 d->the_pc->in[key - '0']->get_name());
        mvprintw(18, 10, " %-58s ", s);
        refresh();
    }

   
    return 1;
}

static uint32_t io_display_obj_info(object *o)
{
  char s[80];
  uint32_t i, l;
  uint32_t n;

  for (i = 0; i < 79; i++) {
    s[i] = ' ';
  }
  s[79] = '\0';

  l = strlen(o->get_description());
  for (i = n = 0; i < l; i++) {
    if (o->get_description()[i] == '\n') {
      n++;
    }
  }

  for (i = 0; i < n + 4; i++) {
    mvprintw(i, 0, s);
  }

  io_object_to_string(o, s, 80);
  mvprintw(1, 0, s);
  mvprintw(3, 0, o->get_description());

  mvprintw(n + 5, 0, "Hit any key to continue.");

  refresh();
  getch();

  return 0;  
}

static uint32_t io_inspect_eq(dungeon_t *d);
static uint32_t io_inspect_in(dungeon_t *d)
{
  uint32_t i, key;
  char s[61];

  for (i = 0; i < MAX_INVENTORY; i++) {
    io_object_to_string(d->the_pc->in[i], s, 61);
    mvprintw(i + 6, 10, " %c) %-55s ", '0' + i,
             d->the_pc->in[i] ? d->the_pc->in[i]->get_name() : "");
  }
  mvprintw(16, 10, " %-58s ", "");
  mvprintw(17, 10, " %-58s ", "Inspect which item (ESC to cancel, '/' for equipment)?");
  refresh();

  while (1) {
    if ((key = getch()) == 27 /* ESC */) {
      io_display(d);
      return 1;
    }

    if (key == '/') {
      io_display(d);
      io_inspect_eq(d);
      return 1;
    }

    if (key < '0' || key > '9') {
      if (isprint(key)) {
        snprintf(s, 61, "Invalid input: '%c'.  Enter 0-9 or ESC to cancel.",
                 key);
        mvprintw(18, 10, " %-58s ", s);
      } else {
        mvprintw(18, 10, " %-58s ",
                 "Invalid input.  Enter 0-9 or ESC to cancel.");
      }
      refresh();
      continue;
    }

    if (!d->the_pc->in[key - '0']) {
      mvprintw(18, 10, " %-58s ", "Empty inventory slot.  Try again.");
      refresh();
      continue;
    }

    io_display(d);
    io_display_obj_info(d->the_pc->in[key - '0']);
    io_display(d);
    return 1;
  }

  return 1;
}
static uint32_t io_inspect_monster(dungeon_t *d)
{
  uint32_t n;
  pair_t dest, tmp;
  int c;
  fd_set readfs;
  struct timeval tv;
  char s[80];
  const char *p;

  io_display(d);

  mvprintw(0, 0, "Choose a monster.  't' to select; 'ESC' to cancel.");

  dest[dim_y] = d->the_pc->position[dim_y];
  dest[dim_x] = d->the_pc->position[dim_x];

  mvaddch(dest[dim_y] + 1, dest[dim_x], '*');
  refresh();

  do {
    do{
      FD_ZERO(&readfs);
      FD_SET(STDIN_FILENO, &readfs);

      tv.tv_sec = 0;
      tv.tv_usec = 125000; /* An eigth of a second */

      io_redisplay_visible_monsters(d);
    } while (!select(STDIN_FILENO + 1, &readfs, NULL, NULL, &tv));
    /* Can simply draw the terrain when we move the cursor away, *
     * because if it is a character or object, the refresh       *
     * function will fix it for us.                              */
    switch (mappair(dest)) {
    case ter_wall:
    case ter_wall_immutable:
    case ter_unknown:
      mvaddch(dest[dim_y] + 1, dest[dim_x], ' ');
      break;
    case ter_floor:
    case ter_floor_room:
      mvaddch(dest[dim_y] + 1, dest[dim_x], '.');
      break;
    case ter_floor_hall:
      mvaddch(dest[dim_y] + 1, dest[dim_x], '#');
      break;
    case ter_debug:
      mvaddch(dest[dim_y] + 1, dest[dim_x], '*');
      break;
    case ter_stairs_up:
      mvaddch(dest[dim_y] + 1, dest[dim_x], '<');
      break;
    case ter_stairs_down:
      mvaddch(dest[dim_y] + 1, dest[dim_x], '>');
      break;
    default:
 /* Use zero as an error symbol, since it stands out somewhat, and it's *
  * not otherwise used.                                                 */
      mvaddch(dest[dim_y] + 1, dest[dim_x], '0');
    }
    tmp[dim_y] = dest[dim_y];
    tmp[dim_x] = dest[dim_x];
    switch ((c = getch())) {
    case '7':
    case 'y':
    case KEY_HOME:
      tmp[dim_y]--;
      tmp[dim_x]--;
      if (dest[dim_y] != 1 &&
          can_see(d, d->the_pc->position, tmp, 1)) {
        dest[dim_y]--;
      }
      if (dest[dim_x] != 1 &&
          can_see(d, d->the_pc->position, tmp, 1)) {
        dest[dim_x]--;
      }
      break;
    case '8':
    case 'k':
    case KEY_UP:
      tmp[dim_y]--;
      if (dest[dim_y] != 1 &&
          can_see(d, d->the_pc->position, tmp, 1)) {
        dest[dim_y]--;
      }
      break;
    case '9':
    case 'u':
    case KEY_PPAGE:
      tmp[dim_y]--;
      tmp[dim_x]++;
      if (dest[dim_y] != 1 &&
          can_see(d, d->the_pc->position, tmp, 1)) {
        dest[dim_y]--;
      }
      if (dest[dim_x] != DUNGEON_X - 2 &&
          can_see(d, d->the_pc->position, tmp, 1)) {
        dest[dim_x]++;
      }
      break;
    case '6':
    case 'l':
    case KEY_RIGHT:
      tmp[dim_x]++;
      if (dest[dim_x] != DUNGEON_X - 2 &&
          can_see(d, d->the_pc->position, tmp, 1)) {
        dest[dim_x]++;
      }
      break;
    case '3':
    case 'n':
    case KEY_NPAGE:
      tmp[dim_y]++;
      tmp[dim_x]++;
      if (dest[dim_y] != DUNGEON_Y - 2 &&
          can_see(d, d->the_pc->position, tmp, 1)) {
        dest[dim_y]++;
      }
      if (dest[dim_x] != DUNGEON_X - 2 &&
          can_see(d, d->the_pc->position, tmp, 1)) {
        dest[dim_x]++;
      }
      break;
    case '2':
    case 'j':
    case KEY_DOWN:
      tmp[dim_y]++;
      if (dest[dim_y] != DUNGEON_Y - 2 &&
          can_see(d, d->the_pc->position, tmp, 1)) {
        dest[dim_y]++;
      }
      break;
    case '1':
    case 'b':
    case KEY_END:
      tmp[dim_y]++;
      tmp[dim_x]--;
      if (dest[dim_y] != DUNGEON_Y - 2 &&
          can_see(d, d->the_pc->position, tmp, 1)) {
        dest[dim_y]++;
      }
      if (dest[dim_x] != 1 &&
          can_see(d, d->the_pc->position, tmp, 1)) {
        dest[dim_x]--;
      }
      break;
    case '4':
    case 'h':
    case KEY_LEFT:
      tmp[dim_x]--;
      if (dest[dim_x] != 1 &&
          can_see(d, d->the_pc->position, tmp, 1)) {
        dest[dim_x]--;
      }
      break;
    }
  } while ((c == 't' && (!charpair(dest) || charpair(dest) == d->the_pc)) ||
           (c != 't' && c != 27 /* ESC */));

  if (c == 27 /* ESC */) {
    io_display(d);
    return 1;
  }

  snprintf(s, 80,"%s, %d speed, %d HP, %d+%dd%d damage                                  ",
           charpair(dest)->name,
           charpair(dest)->speed,
           charpair(dest)->hp,
           charpair(dest)->damage->get_base(),
           charpair(dest)->damage->get_number(),
           charpair(dest)->damage->get_sides());

  for (n = 0, p = ((npc *) charpair(dest))->description; *p; p++) {
    if (*p == '\n') {
      n++;
    }
  }

  mvprintw(0, 0, s);
  mvprintw(2, 0, ((npc *) charpair(dest))->description);
  mvprintw(n + 4, 0, "Hit any key to continue. ");

  refresh();
  
  getch();

  io_display(d);

  return 0;  
}
static uint32_t io_inspect_eq(dungeon_t *d)
{
  uint32_t i, key;
  char s[61], t[61];

  for (i = 0; i < num_eq_slots; i++) {
    sprintf(s, "[%s]", eq_slot_name[i]);
    io_object_to_string(d->the_pc->eq[i], t, 61);
    mvprintw(i + 5, 10, " %c %-9s) %-45s ", 'a' + i, s, t);
  }
  mvprintw(17, 10, " %-58s ", "");
  mvprintw(18, 10, " %-58s ", "Inspect which item (ESC to cancel, '/' for inventory)?");
  refresh();

  while (1) {
    if ((key = getch()) == 27 /* ESC */) {
      io_display(d);
      return 1;
    }

    if (key == '/') {
      io_display(d);
      io_inspect_in(d);
      return 1;
    }

    if (key < 'a' || key > 'l') {
      if (isprint(key)) {
        snprintf(s, 61, "Invalid input: '%c'.  Enter a-l or ESC to cancel.",
                 key);
        mvprintw(18, 10, " %-58s ", s);
      } else {
        mvprintw(18, 10, " %-58s ",
                 "Invalid input.  Enter a-l or ESC to cancel.");
      }
      refresh();
      continue;
    }

    if (!d->the_pc->eq[key - 'a']) {
      mvprintw(18, 10, " %-58s ", "Empty equipment slot.  Try again.");
      continue;
    }

    io_display(d);
    io_display_obj_info(d->the_pc->eq[key - 'a']);
    io_display(d);
    return 1;
  }

  return 1;
}
uint32_t io_expunge_in(dungeon_t *d)
{
    uint32_t i, key;
    char s[61];

 
    for (i = 0; i < MAX_INVENTORY; i++) {
      
        mvprintw(i + 6, 10, " %c) %-55s ", '0' + i,
                 d->the_pc->in[i] ? d->the_pc->in[i]->get_name() : "");
    }
    mvprintw(16, 10, " %-58s ", "");
    mvprintw(17, 10, " %-58s ", "Destroy which item (ESC to cancel)?");
    refresh();

    while (1) {
        if ((key = getch()) == 27 /* ESC */) {
            io_display(d);
          
            return 1;
        }

        if (key < '0' || key > '9') {
            if (isprint(key)) {
                snprintf(s, 61, "Invalid input: '%c'.  Enter 0-9 or ESC to cancel.",
                         key);
                mvprintw(18, 10, " %-58s ", s);
            } else {
                mvprintw(18, 10, " %-58s ",
                         "Invalid input.  Enter 0-9 or ESC to cancel.");
            }
            refresh();
            continue;
        }

        if (!d->the_pc->in[key - '0']) {
            mvprintw(18, 10, " %-58s ", "Empty inventory slot.  Try again.");
            continue;
        }

        if (!d->the_pc->destroy_in(key - '0')) {
            io_display(d);

            return 1;
        }

        snprintf(s, 61, "Can't destroy %s.  Try again.",
                 d->the_pc->in[key - '0']->get_name());
        mvprintw(18, 10, " %-58s ", s);
        refresh();
    }

    return 1;
}

void io_handle_input(dungeon_t *d)
{
    uint32_t fail_code;
    int key;

    do {
        switch (key = getch()) {
            case '7':
            case 'y':
            case KEY_HOME:
                fail_code = move_pc(d, 7);
                break;
            case '8':
            case 'k':
            case KEY_UP:
                fail_code = move_pc(d, 8);
                break;
            case '9':
            case 'u':
            case KEY_PPAGE:
                fail_code = move_pc(d, 9);
                break;
            case '6':
            case 'l':
            case KEY_RIGHT:
                fail_code = move_pc(d, 6);
                break;
            case '3':
            case 'n':
            case KEY_NPAGE:
                fail_code = move_pc(d, 3);
                break;
            case '2':
            case 'j':
            case KEY_DOWN:
                fail_code = move_pc(d, 2);
                break;
            case '1':
            case 'b':
            case KEY_END:
                fail_code = move_pc(d, 1);
                break;
            case '4':
            case 'h':
            case KEY_LEFT:
                fail_code = move_pc(d, 4);
                break;
            case '5':
            case ' ':
            case KEY_B2:
                fail_code = 0;
                break;
            case '>':
                fail_code = move_pc(d, '>');
                break;
            case '<':
                fail_code = move_pc(d, '<');
                break;
            case 'S':
                d->save_and_exit = 1;
                character_reset_turn(d->the_pc);
                fail_code = 0;
                break;
            case 'Q':
                d->quit_no_save = 1;
                fail_code = 0;
                break;
            case 'T':
                /* New command.  Display the distances for tunnelers.             */            io_display_tunnel(d);
                fail_code = 1;
                break;
            case 'D':
                /* New command.  Display the distances for non-tunnelers.         */
                io_display_distance(d);
                fail_code = 1;
                break;
            case 'H':
                /* New command.  Display the hardnesses.                          */
                io_display_hardness(d);
                fail_code = 1;
                break;
            case 's':
                /* New command.  Return to normal display after displaying some   *
                 * special screen.                                                */
                io_display(d);
                fail_code = 1;
                break;
            case 'g':
                /* Teleport the PC to a random place in the dungeon.              */
                io_teleport_pc(d);
                fail_code = 0;
                break;
            case 'm':
                io_list_monsters(d);
                fail_code = 1;
                break;
            case 'f':
	        io_display_no_fog(d);
                fail_code = 1;
                break;
            case 'a':
                io_display_all(d);
                fail_code = 1;
                break;
            case 'w':
                fail_code = io_wear_eq(d);
                break;
            case 't':
                fail_code = io_remove_eq(d);
                break;
            case 'd':
                fail_code = io_drop_in(d);
                break;
            case 'x':
                fail_code = io_expunge_in(d);
                break;
            case 'i':
                io_display_in(d);
                fail_code = 1;
                break;
            case 'e':
                io_display_eq(d);
                fail_code = 1;
                break;
            case 'c':
                io_display_ch(d);
                fail_code = 1;
                break;
             case 'I':
	       io_inspect_in(d);
	       fail_code = 1;
	       break;
	     case 'L':
	       io_inspect_monster(d);
	       fail_code = 1;
	       break;
            case 'q':
                /* Demonstrate use of the message queue.  You can use this for *
                 * printf()-style debugging (though gdb is probably a better   *
                 * option.  Not that it matterrs, but using this command will  *
                 * waste a turn.  Set fail_code to 1 and you should be able to *
                 * figure out why I did it that way.                           */
                io_queue_message("This is the first message.");
                io_queue_message("Since there are multiple messages, "
                                         "you will see \"more\" prompts.");
                io_queue_message("You can use any key to advance through messages.");
                io_queue_message("Normal gameplay will not resume until the queue "
                                         "is empty.");
                io_queue_message("Long lines will be truncated, not wrapped.");
                io_queue_message("io_queue_message() is variadic and handles "
                                         "all printf() conversion specifiers.");
                io_queue_message("Did you see %s?", "what I did there");
                io_queue_message("When the last message is displayed, there will "
                                         "be no \"more\" prompt.");
                io_queue_message("Have fun!  And happy printing!");
                fail_code = 0;
                break;
            case 'R':
            case 'r':
                fail_code = io_print_spells(d);
                break;
            case '$':
                io_print_shop(d);
                fail_code = 0;
                break;
            default:
                /* Also not in the spec.  It's not always easy to figure out wha *
                 * key code corresponds with a given keystroke.  Print out any    *
                 * unhandled key here.  Not only does it give a visual error      *
                 * indicator, but it also gives an integer value that can be used *
                 * for that key in this (or other) switch statements.  Printed in *
                 * octal, with the leading zero, because ncurses.h lists codes in *
                 * octal, thus allowing us to do reverse lookups.  If a key has a *
                 * name defined in the header, you can use the name here, else    *
                 * you can directly use the octal value.                          */
                mvprintw(0, 0, "Unbound key: %#o ", key);
                fail_code = 1;
        }
    } while (fail_code);
}


void io_print_hp(dungeon_t *d){
    int colored = int(16 * d->the_pc->hp/(double) PC_HP+0.5);

    mvprintw(23, 1, "HP ""                ");

    char buf[50];
    sprintf(buf, "%d/%d (%u)""                ", d->the_pc->hp, PC_HP, d->the_pc->hp_potions);
    buf[16] = 0;

    char coloredsubstr[colored + 1];
    memset(coloredsubstr, 0, sizeof(coloredsubstr));
    strncpy(coloredsubstr, buf, colored);

    attron(COLOR_PAIR(COLOR_HP));
    mvprintw(23, 4, "%s", coloredsubstr);
    attroff(COLOR_PAIR(COLOR_HP));

    if (colored < 16)
        mvprintw(23, 4 + colored, "%s", buf + colored);
}


void io_print_mp(dungeon_t *d){
    int colored = int(16 * d->the_pc->mp/(double)PC_MP+0.5);

    mvprintw(23, 21, "MP ""                ");

    char buf[50];
    sprintf(buf, "%d/%d (%u)""                ", d->the_pc->mp, PC_MP, d->the_pc->mana_potions);
    buf[16] = 0;

    char coloredsubstr[colored + 1];
    memset(coloredsubstr, 0, sizeof(coloredsubstr));
    strncpy(coloredsubstr, buf, colored);

    attron(COLOR_PAIR(COLOR_MP));
    mvprintw(23, 24, "%s", coloredsubstr);
    attroff(COLOR_PAIR(COLOR_MP));

    if (colored < 16)
        mvprintw(23, 24 + colored, "%s", buf + colored);
}

void io_print_gold(dungeon_t *d){
    char buf[50];
    sprintf(buf, "%d""G", d->the_pc->gold);
    buf[16] = 0;

    attron(COLOR_PAIR(COLOR_GOLD));
    mvprintw(23, 44, "%s", buf);
    attroff(COLOR_PAIR(COLOR_GOLD));
}

void io_print_level(dungeon_t *d){
    mvprintw(22, 1, "Lv: %u", d->the_pc->level);
}

void io_print_hud(dungeon_t *d){
    io_print_hp(d);
    io_print_mp(d);
    io_print_gold(d);
    io_print_level(d);
}

uint32_t io_print_spells(dungeon_t *d){
    int color = COLOR_CYAN;
    char s[61];
   

    attron(COLOR_PAIR(color));
    mvprintw(19, 21, "b: Blast nearby area   cost: 250 ");
    mvprintw(20, 21, "h: Heal PC +100      cost: 100 ");
    mvprintw(21, 21, "T: Teleport without cheating           cost: 500 ");
    mvprintw(22, 21, "y: Revitalize       cost: 700 ");
    mvprintw(23, 21, "z: Restore          cost: 1000");
    attroff(COLOR_PAIR(color));

    refresh();

    int cost;

    while(1) {
        int ch = getch();
        if(ch == 27 || ch == 'Q' || ch == 'q') {
            break;
        } else if (ch =='B' || ch =='b'){
            if (d->the_pc->mp < (cost = 250))
                break;
            for (int r = d->the_pc->position[dim_x] - 1;
                 r <= d->the_pc->position[dim_y] + 1; r++) {
                for (int c = d->the_pc->position[dim_x] - 1;
                     c <= d->the_pc->position[dim_x] + 1; c++) {
                    if (r >= 0 && r < 21 &&
                        c >= 0 && c < 80 &&
                        d->hardness[r][c] != ter_wall_immutable) {
                        if (d->hardness[r][c] > 0) {
                            d->hardness[r][c] = 0;
                            d->map[r][c] = ter_floor_hall;
                        }

                        if (d->charmap[r][c] && d->charmap[r][c] != d->the_pc) {
                            d->charmap[r][c]->hp /= 10;
                        }
                    }
                }
            }
            d->the_pc->mp -= cost;
            refresh();
            break;
        } else if (ch == 'h'){
            if (d->the_pc->mp < (cost = 100))
                break;
            d->the_pc->hp += PC_HP * 0.1;
            if (d->the_pc->hp > PC_HP) {
                d->the_pc->hp = PC_HP;
            }
            d->the_pc->mp -= cost;
            io_print_hp(d);
            io_print_mp(d);
            break;
        } else if (ch == 'y'){
            if (d->the_pc->mp < (cost = 700))
                break;
            d->the_pc->hp += PC_HP * 0.5;
            if (d->the_pc->hp > PC_HP) {
                d->the_pc->hp = PC_HP;
            }
            d->the_pc->mp -= cost;
            io_print_hp(d);
            io_print_mp(d);
            break;
	}
	 else if (ch == 'z'){
            if (d->the_pc->mp < (cost = 1000))
                break;
            d->the_pc->hp += PC_HP * 1.0;
            if (d->the_pc->hp > PC_HP) {
                d->the_pc->hp = PC_HP;
            }
            d->the_pc->mp -= cost;
            io_print_hp(d);
            io_print_mp(d);
            break;
	 }
        else if (ch =='T' || ch =='t') {
            if (d->the_pc->mp < (cost = 500))
                break;
            io_teleport_pc(d);
            d->the_pc->mp -= 500;
            io_print_mp(d);
            break;
        } else {
            if (isprint(ch)) {
                snprintf(s, 61, "Invalid input: '%c'.  Enter 0-9 or ESC to cancel.",
                         ch);
                mvprintw(18, 10, " %-58s ", s);
            } else {
                mvprintw(18, 10, " %-58s ",
                         "Invalid input.  Enter 0-9 or ESC to cancel.");
            }
            refresh();
            break;
        }
    }
  
    return 1;
}

int io_print_shop(dungeon_t *d) {
    uint32_t i, key;
    char s[61];

   
    for (i = 0; i < SHOP_MAX; i++) {
        io_object_to_string(d->shop[i], s, 61);
        mvprintw(i + 6, 10, " %c) %-55s", '0' + i, s);
    }
    mvprintw(14, 10, " %-58s ", "(m) mana   potion - 200MP   50G");
    mvprintw(15, 10, " %-58s ", "(h) health potion - 200HP   100G");
    mvprintw(16, 10, " %-58s ", "");
    mvprintw(17, 10, " %-58s ", "How goes it, good sir?");
    refresh();

    while (1) {
        if ((key = getch()) == 27 /* ESC */) {
            io_display(d);
           
            return 1;
        }
        //Key out of range, not m or h
        if ((key < '0' || key > '0' + SHOP_MAX - 1) && (key != 'm' && key != 'h') ) {
            if (isprint(key)) {
                snprintf(s, 61, "Invalid input: '%c'.  Enter 0-4, m/h or ESC to cancel.",
                         key);
                mvprintw(18, 10, " %-58s ", s);
            } else {
                mvprintw(18, 10, " %-58s ",
                         "Invalid input.  Enter 0-4, m/h or ESC to cancel.");
            }
            refresh();
            continue;
        }

        if (key == 'm' && d->the_pc->gold >= 50) {
            d->the_pc->gold -= 50;
            d->the_pc->mana_potions++;
            mvprintw(18, 10, " %-58s ", "10 POINTS TO GRYFFINDOR!");
            continue;
        } else if (key == 'h' && d->the_pc->gold >= 100) {
            d->the_pc->gold -= 100;
            d->the_pc->hp_potions++;
            mvprintw(18, 10, " %-58s ", "YER A WIZARD, HARRY");
            continue;
        } else if (!d->shop[key - '0']) {
            mvprintw(18, 10, " %-58s ", "WHAT ER YER WHIPPERSHNAPPERS TRYNNA DO?");
            continue;
        } else if (d->shop[key - '0']->get_value() > d->the_pc->gold) {
            mvprintw(18, 10, " %-58s ", "YOU HAVEN'T ANY BOOTY! WHERE'S YER MONEY, YE DERN SCALLYWAG???");
            continue;
        } else {
            d->the_pc->gold -= d->shop[key - '0']->get_value();
            d->objmap[d->the_pc->position[dim_y]][d->the_pc->position[dim_x]]
                    = d->shop[key - '0'];
            d->shop[key - '0'] = 0;
            mvprintw(18, 10, " %-58s ", "A FINE CHOICE!!");
            continue;
        }

    }
}
