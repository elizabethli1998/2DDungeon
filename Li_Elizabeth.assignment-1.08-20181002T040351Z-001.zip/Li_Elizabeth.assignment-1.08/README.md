This 1.08 Assignment implements the monster and object parser feature and takes the info
from the files and puts it in form of actual objects and monsters in the game. The objects
and monsters should follow what is mentioned in the description, if the fields are valid.

Given a text file full of monster and object escriptions with those given values and inputs,
the monster parser and object parser will take those descriptions and output them onto the map in forms
of whatever symbols and colors they were given. All of the other fields that were valid
shall be implemented for the monsters and objects as well.

-rlg327.cpp now no longer shows just the parser and instead, the actual game once again.
-Descriptions.cpp and descriptions.h have been adjusted to advocate for objects and monsters
-Object.cpp and object.h were created to help better organize code and allow objects
be used in form of classes. 
-npc.cpp and npc.h were adjusted to account for the monsters and their traits. The
gen_monsters method takes in whatever was parsed into the game and outputs it in
form of a monster, with the rarity and other features being implemented along with colors.
For testing purposes and for the sake of playing the game, I made some adjustments
to the number of monsters being generated to make it easier to play the game
and to better test my code/see if what was implemented would actually appear in the game.
To display more monsters that were parsed from the files, simply comment out the 
if statements after the num_monsters were first initalized. 
-The object files basically do the same thing, with generating the objects onto
the game. The spec states to have at least 10 objects appear, which happens. The only
thing is that sometimes, multiple different objects appear in the same room, so some
exploring the dungeon may be necessary to ensure that the objects are there.


To run the game, just use the command "./rlg327" and to compile, call
"make all". Clean with "make clobber"