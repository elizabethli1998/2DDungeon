Changelog

All notable changes to the project will be documented in this file


## 0.01 - 2018-1-18
### Added
-This Changefile to keep track of updates and changes to Assignment1.01
-README file to explain this week's projects and important features and functions
-Created 2D dungeon array and another 2D array to keep track of room dimensions
-Setting up rock
-Set up entering a number for number of rooms wanted, through commandline 1-5

## 0.02 - 2018-1-20
### Added
-A function for creating the rooms, called makeRooms, inputting the number that is input by the user on the commandline that sets up the rooms and their widths and heights. 


##0.03 - 2018-1-21
### Added
-A function for checking to see if making the rooms at particular areas are valid or not
-Fixed the memory issues and speeding up the functions through srand and accounting for no infinite loops
-Thought of logic behind making and printing the paths


##0.04 - 2018-1-22
### Added
-Wrote the functions for printing the paths
-Wrote makePaths, the function that builds the paths based on the number of rooms input
-Wrote buildPath, the function that actually assigns values in the arrays for making the paths
-Wrote printPath, the function for printing the paths as "#" on the screen


##0.04 - 2018-1-23
### Added
-makefile for Assignment1.01
-Eliminated repetitive code
-Updated Changelog
-Updated README
-Made the dungeon less linear by giving it a 20% chance of creating a path that is not linear.

## 0.05 - 2018-1-27
-Added professor's solution
-Deciphered it

## 0.06 -2018-1-28
-Implemented load functionality
-Implemented save functionality

## 0.07 -2018-1-29
-Added the tags to the main method to be able to run everything
-Cleaned up code
## 0.08 - 2018-1-30
-Cleaned up more code
--Added readme

## 0.08 -2018-2-2
-Attempted to figure out placing PC on the screen
	
## 0.09 -2018-2-4
-Modified Dijkstra's methods
-Started implementing calculating the distances
## 0.10 -2018-2-8
-Started implementing the renderMap function
-Played around with using the distances to get distanceMaps
## 0.11 -2018-2-11
-made README
-Worked on distance and render functions to get more accurate tunneling maps
## 0.12 -2018-2-17
-Added to dungeon.h
-Added to dungeon.c
-Created monsters.c
-Created monsters.h
-Added movement possibilities for monsters
-Made the program stop once monsters touch PC
-Updated priority Queue
-Worked on the events
## 0.13 -2018-2-18
-Updated event and heap
-Updated monster information with speed and location characteristics.
-Made it so that monsters do not appear in the same room as the PC
-Updated PC placement, as there was a bug where the PC starts off not in a room
-Fixed segfault errors
-Fixed the comparison function for priority queue
## 0.14 -2018-2-19
-Updated readme
-Fixed speeds and some calculations for the monster statuses
-Fixed Player move functionality
-Changed some of the monster behavior so it better fits what is in the spec
-Updated rlg327.c file to accommadate for the dungeon. and monsters.c files

## 0.15 -2018-2-22
-added Ncurses
-Added controls for movement
-Updated files to add Ncurses and implement the library

## 0.16 -2018-2-23
-Updated readme
-Added stair functionality
-Removed PC tunneling power from professor solution code
-Updated rlg327.c to implement everything added, including the win/lose messages.

## 0.17 -2018-3-9
-Ported character.cpp
-Ported npc.cpp
-Ported pc.cpp
-Got rid of unnecessary code that was irrelevant to the project

## 0.18 -2018-3-11
-Added memory for pc
-Added sight features
-Added fog of war features

## 0.19 -2018-3-12
-Adjusted illuminated feature
-Added functions to help with npc and pc movement
-Added key for turning off fog of war

## 0.20 -2018-3-15
-Made it so turning off fog of war counted as a turn (made it easier to code)
-Started teleportation
-Added randomization teleportation feature

## 0.21 -2018-3-20
-Fixed bugs
-ATTEMPTED to add onto teleportation feature
-Created README

## 0.22 -2018-3-26
-Commented out dungeon stuff
-Added the parsing files
-Set up the outputs for the instream files

## 0.23 -2018-3-27
-Did some testing
-Made README

## 0.24 -2018-3-30
-Downloaded solution code
-Made some changes to solution code so it more closely resembles my previous solutions
-Added to descriptions.cpp
-Destroyed parser and implemented the dungeon back to where it was in 1.06

## 0.25 -2018-3-31
-Added object.cpp and object.h files
-Implemented the monster spawning feature that was read from file
-Started the object spawning feature that was read from file
-Added all of the necessary items for .h to get object and monsters working

## 0.26 -2018-4-2
-enhanced the spawning features for both object and monsters
-Did some testing
-Made README
-Cleaned up some code
