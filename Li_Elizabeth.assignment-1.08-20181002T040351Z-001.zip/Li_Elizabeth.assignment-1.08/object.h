
#ifndef CS327_OBJECT_H
#define CS327_OBJECT_H

#include <string>

# include "dims.h"
# include "character.h"
# include "dice.h"
# include <vector>
# include <string>
# include "descriptions.h"

#define WEAPON_SYMB '|'
#define OFFHAND_SYMB ')'
#define RANGED_SYMB '}'
#define ARMOR_SYMB '['
#define HELMET_SYMB ']'
#define CLOAK_SYMB '('
#define GLOVES_SYMB '{'
#define BOOTS_SYMB '\\'
#define RING_SYMB '='
#define AMULET_SYMB '"'
#define LIGHT_SYMB '_'
#define SCROLL_SYMB '~'
#define BOOK_SYMB '?'
#define FLASK_SYMB '!'
#define GOLD_SYMB '$'
#define AMMUNITION_SYMB '/'
#define FOOD_SYMB ','
#define WAND_SYMB '-'
#define CONTAINER_SYMB '%'
#define STACK_SYMB '&'

using namespace std;

typedef struct dungeon dungeon_t;

class object {
public:
    string name,description;
    pair_t position;
    object_type_t type;
    bool art;
    char symbol;
    uint32_t color;
    int32_t hit_bonus,dge_bonus,def_bonus,weight,spd_bonus,value,spec_attr;
    dice dam_bonus;
    uint32_t rarity;

      object(void);
    // object(string name, string description, bool art, char symbol,  uint32_t color, uint32_t rarity);

};
void gen_objects(dungeon_t *d);
int8_t *object_get_pos(const object *o);
uint32_t object_get_color(const object *o);
char object_get_symbol(const object *o);

#endif //CS327_OBJECT_H
